@extends('layouts.admin.app')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
 
        <div class="row">
            <!-- Statistics Cards -->
            <div class="col-sm-12">
                <div class="card w-20 mx-auto">
                    <div class="card-body text-center">
                     <h2>Dont have permission to access this page </h1>
                    </div>
                </div>
            </div>
           


         
           

        </div>
    </div>
@endsection
