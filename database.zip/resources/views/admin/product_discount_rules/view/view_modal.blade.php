  
   
   <x-displayViewData :module="$module" :row1="$row" :modelRelations="$model_relations" :viewColumns="$view_columns"
                            :imageFieldNames="$image_field_names" :storageFolder="$storage_folder" :repeatingGroupInputs="$repeating_group_inputs"/>
                    