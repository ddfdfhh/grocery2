<?php
use Image as Image;
use ImageOptimizer as ImageOptimizer;
if (!function_exists('baseUrl')) {
    function baseUrl()
    {
        return config('app.base_url');
    }
}
function getLastDayOfMonth($date = null)
{
    return $date ? date("d", strtotime(date("Y-m-t", strtotime($date)))) : date("d", strtotime(date("Y-m-t")));
}
function monthIndexFromName($name)
{
    $months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return array_search($months, $name);
}
function monthsArray()
{
    return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

}
function schoolSession()
{
    $session = '';
    $current_month = intval(date("m"));

    $data['session_start_month'] = \DB::table('setting')->first()->session_start_month;

    if ($current_month > $data['session_start_month']) {
        $session = date('Y') . '-' . (intval(date('y')) + 1);
    } else {
        $session = (intval(date('y')) - 1) . '-' . date('Y');
    }
    return $session;
}
if (!function_exists('adminUrl')) {
    function adminUrl()
    {
        return config('app.admin_subdomain') . '.' . baseUrl();
    }
}
if (!function_exists('formateDate')) {
    function formateDate($v, $show_time = false)
    {
        return strlen($v) > 2 ? ($show_time ? date('j M,Y h:i a', strtotime($v)) : date('j M,Y', strtotime($v))) : '';
    }
}
if (!function_exists('formateNumber')) {
    function formateNumber($v, $decimal = 2)
    {
        return strlen($v) > 0 ? number_format($v, $decimal) : '';
    }
}
if (!function_exists('showInInr')) {
    function showInInr($v)
    {
        return '₹' . formateNumber($v);
    }
}
function getFieldById($model, $id, $field)
{
    $mod = app("App\\Models\\$model");
    $model = $mod->find($id);
    return $model->{$field};

}
function getCount($table, $where = [])
{
    return count($where) > 0?\DB::table($table)->where($where)->count() : \DB::table($table)->count();

}
function getArrayFromModel($model, $fields_label = [])
{
    $mod = app("App\\Models\\$model");
    $fields = $mod->getFillable();
    return array_combine($fields_label, $fields);

}
function getNameToIdPairFromModel($model, $array_names = [])
{
    $mod = app("App\\Models\\$model");
    return $mod->whereIn('name', $array_names)->get(['id', 'name'])->toArray();

}
function extractNameOnlyAsArray($val = [])
{

    return array_map(function ($v) {
        return explode("-", $v)[1];

    }, $val);

}
function convertToKeyValPair($val = [])
{

    return array_map(function ($v) {
        $r = explode("-", $v);
        return ["id" => $r[0], "key" => $r[1]];

    }, $val);

}
function renderSelectOptionsFromJsonCOlumnOfIdNamePair($json_val = [])
{

    return array_map(function ($v) {
        $r = explode("-", $v);
        return [$r[0] => $r[1]];

    }, $val);

}
function properPluralName($str)
{

    return ucwords(str_replace('_', ' ', $str));

}
function properSingularName($str)
{
    $g = ucwords(str_replace('_', ' ', \Str::singular($str)));
    $g = str_replace(' Id', ' ', $g);
    return $g;

}
function modelName($str)
{
    $str = \Str::singular($str);
    $spl = explode('_', $str);
    $spl = array_map(function ($v) {
        return ucfirst($v);
    }, $spl);
    $new_str = implode('', $spl);
    return $new_str;

}
function isFieldBelongsToManyToManyRelation($rel_ar, $field)
{
    $found = -1;
    $i = 0;
    foreach ($rel_ar as $item) {
        if ($field == $item['name'] && $item['type'] == 'BelongsToMany') {
            $found = $i;
            break;
        }
        $i++;
    }
    return $found;
}
function isFieldBelongsToHasManyRelation($rel_ar, $field)
{
    $found = -1;
    $i = 0;
    foreach ($rel_ar as $item) {
        if ($field == $item['name'] && $item['type'] == 'HasMany') {
            $found = $i;
            break;
        }
        $i++;
    }
    return $found;
}
function isFieldPresentInRelation($rel_ar, $field)
{
    $found = -1;
    $i = 0;
    foreach ($rel_ar as $item) {
        if (($item['name'] == $field) || ($item['name'] . '_id' == $field)) {
            $found = $i;

            break;
        }
        $i++;
    }
    return $found;
}
function isFieldPresentInRelationTableAsColumn($rel_ar, $field)
{
    $found = -1;
    $i = 0;
    foreach ($rel_ar as $item) {
        $class = $item['class'];
        $table = app($class)->getTable();
        $columns = \DB::getSchemaBuilder()->getColumnListing($table);

        if (in_array($field, $columns)) {
            $found = $i;

            break;

            $i++;
        }
    }
    return $found;
}
function isFieldPresentInTableAsColumn($model_class, $field)
{
    $table = app($model_class)->getTable();
    $columns = \DB::getSchemaBuilder()->getColumnListing($table);

    $found = -1;

    if (in_array($field, $columns)) {
        $found = 1;

    }

    return $found;
}

function getForeignKeyFieldValue($rel_ar, $row, $field)
{

    $resp = '';

    // $item['name'] = 'category';
    // $field = 'category_id';
    foreach ($rel_ar as $item) {
        $field = $field == $item['name'] . '_id' ? $item['name'] : $field; //here field is column which is accosciated to other table $row->state->name //here state is file name is key to get
        //get_by_field===mens relatioship table ka kunsa field access karna hai ye cheej $key_toget_as_per_relation array mein relation name ke saath dikhatee hai ;
        $get_by_field = isset($item['column_to_show_in_view']) ? $item['column_to_show_in_view'] : 'name';
        //dd($field.'==='.$item['name']);
        if ($field == $item['name']) {

            if ($item['type'] == 'BelongsTo' || $item['type'] == 'HasOne') {
                $resp = $row->{$field} ? $row->{$field}->{$get_by_field} : '';
            } elseif ($item['type'] == 'HasMany' || $item['type'] == 'ManyToMany' || $item['type'] == 'BelongsToMany') {

                if ($row->{$field}) {
                    if (count($row->{$field}->toArray()) > 0) {

                        $val_ar = array_column($row->{$field}->toArray(), $get_by_field);
                        $resp = showArrayInColumn($val_ar);

                    }
                }

            }
        }
    }
    return $resp;
}

function getModelRelations($model)
{
    $model = app("App\\Models\\$model");
    $reflector = new \ReflectionClass($model);
    $relations = [];
    foreach ($reflector->getMethods() as $reflectionMethod) {
        $returnType = $reflectionMethod->getReturnType();

        if ($returnType) {
            $type = class_basename($returnType->getName());
            if (in_array($type, ['HasOne', 'HasMany', 'BelongsTo', 'BelongsToMany', 'MorphToMany', 'MorphTo'])) {
                $t = (array) $reflectionMethod;
                $t['type'] = $type;
                $t['save_by_key'] = '';
                $t['column_to_show_in_view'] = 'name';
                if (in_array($type, ['HasMany'])) {
                    $t['save_by_key'] = 'name';
                }
/**can be change in contrller name to other column  */
                unset($t['class']);
                $relations[] = $t;
            }
        }
    }
    return $relations;
}

function getAllModels()
{
    $path = app_path() . "/Models";
    $out = [];
    $results = scandir($path);
    foreach ($results as $result) {
        if ($result === '.' or $result === '..') {
            continue;
        }

        $filename = $result;
        $out[] = substr($filename, 0, -4);

    }
    $out[] = 'Self';
    return $out;

}
function getTables()
{
    return array_map('current', \DB::select('SHOW TABLES'));
}
function getPivotTableName($model1, $model2)
{
    $t = [$model1, $model2];
    sort($t);

    return implode('_', $t);

}
function isJSON($string)
{
    return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
}
function formatPostForJsonColumn($post)
{

    $json_cols = []; /****like storing first part in json field */
    $json_keys = []; /****like storing last part in json field */
    $ar_val = [];
    $no_of_values_in_arr = 0;
    foreach ($post as $key => $val) {
        if (is_array($post[$key])) {
            if (count($post[$key]) > 0) {
                if (str_contains($key, '__json__')) {

                    $spl = explode("__json__", $key);
                    $col_name = $spl[0];
                    $key_name = $spl[1];

                    // $no_of_values_in_arr = count($post[$key]);
                    if (!isset($post[$col_name])) {

                        $json_cols[] = $col_name;

                        $json_keys[] = $key_name; /***like storing size */
                    } else { /****kyunki json column toggle mein bhi hota hai to unko unset karo psot se  */
                        $val = $post[$key];
                        unset($post[$key]);
                        $post[$key_name] = $val[0]; /*toggable div ke case mein ham kewal first val store kara rahe hai not array u can change***/
                    }

                } else { /***if key is index array  */
                    $post[$key] = json_encode($post[$key]);
                }
            } else { /***if key val is empty  */
                $post[$key] = null;
            }

        }
    }

    $json_cols = array_unique($json_cols);

    foreach ($json_cols as $colname) {
        if (count($json_keys) > 0) {

            $p = [];
            foreach ($json_keys as $key) {

                if (isset($post[$colname . '__json__' . $key])) {
                    $values = $post[$colname . '__json__' . $key];
                    $p[$key] = $values;
                }
            }
            $ar_val[$colname][] = $p;

        }

    }
    if (count($ar_val) > 0) {
        foreach ($ar_val as $key => $val) {
            $keys = array_keys($val[0]);
            $val_count = count($val[0][$keys[0]]);

            $t = [];
            for ($i = 0; $i < ($val_count); $i++) {
                $x = [];

                foreach ($keys as $k) {
                    $x[$k] = $val[0][$k][$i];

                }
                $t[] = $x;
            }
            // dd($t);
            $post[$key] = json_encode($t);

        }
    }
//dd($post);
    return $post;
}

function showArrayWithNamesOnly($ar)
{
    $str = '';
    foreach ($ar as $t) {
        $str .= ',' . $t['name'];
    }
    return ltrim($str, ',');
}
function showArrayInColumn($arr = [], $row_index = 0, $by_json_key = 'id', $size = 'md', $title = '', $show_delete = false,
    $delete_data_info = ['row_id_val' => '', 'table' => '', 'json_column_name' => '', 'delete_url' => '']) {
    if (!empty($arr)) {
        if (!is_array($arr)) {
            $arr = $arr->toArray();
        }

        if (isset($arr[0]) && !is_array($arr[0])) {

            return implode(',', $arr);
        } elseif (!isArrayEmpty($arr)) {

            $keys = array_keys($arr[0]);
            $header = '<tr>';
            foreach ($keys as $k) {
                if (!str_contains($k, '_id') && $k != $by_json_key) {
                    $k = str_replace('_', ' ', $k);
                    $k = ucwords($k);
                    $header .= '<th>' . $k . '</th>';
                }

            }
            if ($show_delete) {
                $header .= '<th>Action</th>';
            }

            $header .= '</th>';
            $body = '';
            $i = 0;
            foreach ($arr as $val) {

                $i = isset($by_json_key) && !empty($by_json_key) && isset($val[0]) ? intval($val[0][$by_json_key]) : $i + 1;
                $body .= '<tr  id="row-' . $i . '">';
                foreach ($val as $k => $v) {
                    if (!str_contains($k, '_id') && $k != $by_json_key) {
                        $body .= '<td style="white-space: -o-pre-wrap;
                                        word-wrap: break-word;
                                        white-space: pre-wrap;
                                        white-space: -moz-pre-wrap;
                                        white-space: -pre-wrap; ">' . $v . '</td>';
                    }
                }
                if ($show_delete) {$body .= <<<STR
                        <td><button class="btn btn-xs btn-danger" onClick="deleteJsonColumnData({$delete_data_info["row_id_val"]},'{$by_json_key}','{$delete_data_info["table"]}','{$val[$by_json_key]}','{$delete_data_info["json_column_name"]}','{$delete_data_info["delete_url"]}')"><i class="bx bx-trash"></i></button></td>
                        STR;
                }

                $body .= '</tr>';

            }

            $str = '<button type="button" class="btn-sm btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal' . $row_index . '">
          View
        </button>
        <div class="modal detail" id="myModal' . $row_index . '">
          <div class="modal-dialog modal-' . $size . '">
            <div class="modal-content">
                    <div class="modal-header"><h5 class="modal-title">' . ucwords($title) . '</h5></div>
              <div class="modal-body">
              <div class="table-responsive">
              <table class="table table-bordered" >
              <thead>
              ' . $header . '
              </thead>
              <tbody>' . $body . '</tbody>
              </table>
              </div>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="button" class="btn-sm btn btn-danger" data-bs-dismiss="modal">Close</button>
              </div>

            </div>
          </div>
        </div>';
            return $str;
        }
    } else {
        return '';
    }

}
function showArrayInColumnNotButtonForm($arr = [], $row_index = 0, $by_json_key = 'id', $size = 'md', $title = '', $show_delete = false,
   
$delete_data_info = ['row_id_val' => '', 'table' => '', 'json_column_name' => '', 'delete_url' => '']) {
  
    if (!empty($arr)) {
        if (!is_array($arr)) {
            $arr = $arr->toArray();
        }

        if (isset($arr[0]) && !is_array($arr[0])) {

            return implode(',', $arr);
        } elseif (!isArrayEmpty($arr)) {

            $keys = array_keys($arr[0]);

            $header = '<tr>';
            foreach ($keys as $k) {
                if (!str_contains($k, '_id') && $k != $by_json_key) {
                    $k = str_replace('_', ' ', $k);
                    $k = ucwords($k);
                    $header .= '<th>' . $k . '</th>';
                }

            }

            if ($show_delete) {
                $header .= '<th>Action</th>';
            }

            $header .= '</th>';
            $body = '';
            $i = 0;
            foreach ($arr as $val) {

                $i = isset($by_json_key) && !empty($by_json_key) && isset($val[0]) ? intval($val[0][$by_json_key]) : $i + 1;
                $body .= '<tr  id="row-' . $i . '">';
                foreach ($val as $k => $v) {
                    if (!str_contains($k, '_id') && $k != $by_json_key) {
                        $body .= '<td style="white-space: -o-pre-wrap;
                                        word-wrap: break-word;
                                        white-space: pre-wrap;
                                        white-space: -moz-pre-wrap;
                                        white-space: -pre-wrap; ">' . $v . '</td>';
                    }
                }
                if ($show_delete) {$body .= <<<STR
                        <td><button class="btn btn-xs btn-danger" onClick="deleteJsonColumnData({$delete_data_info["row_id_val"]},'{$by_json_key}','{$delete_data_info["table"]}','{$val[$by_json_key]}','{$delete_data_info["json_column_name"]}','{$delete_data_info["delete_url"]}')"><i class="bx bx-trash"></i></button></td>
                        STR;
                }

                $body .= '</tr>';

            }

            $str = '<div class="table-responsive">
              <table class="table table-bordered" >
              <thead>
              ' . $header . '
              </thead>
              <tbody>' . $body . '</tbody>
              </table>
              </div>
             ';
            return $str;
        }
    } else {
        return '';
    }

}

function showArrayInColumnNoPopup($arr = [], $by_json_key = 'id', $show_delete = false,
    $delete_data_info = ['row_id_val' => '', 'table' => '', 'json_column_name' => '', 'delete_url' => '']) {
    if (!empty($arr)) {
        if (!is_array($arr)) {
            $arr = $arr->toArray();
        }

        if (!is_array($arr[0])) {

            return implode(',', $arr);
        } elseif (isset($arr[0]) && !is_array($arr[0])) {

            return implode(',', $arr);
        } elseif (!isArrayEmpty($arr)) {

            $keys = array_keys($arr[0]);
            $header = '<tr>';
            foreach ($keys as $k) {
                if (!str_contains($k, '_id') && $k != $by_json_key) {
                    $header .= '<th>' . $k . '</th>';
                }

            }
            if ($show_delete) {
                $header .= '<th>Action</th>';
            }

            $header .= '</th>';
            $body = '';
            $i = 0;
            foreach ($arr as $val) {

                $i = isset($by_json_key) && !empty($by_json_key) && isset($val[0]) ? intval($val[0][$by_json_key]) : $i + 1;
                $body .= '<tr  id="row-' . $i . '">';
                foreach ($val as $k => $v) {
                    if (!str_contains($k, '_id') && $k != $by_json_key) {
                        $body .= '<td style="white-space: -o-pre-wrap;
                                        word-wrap: break-word;
                                        white-space: pre-wrap;
                                        white-space: -moz-pre-wrap;
                                        white-space: -pre-wrap; ">' . $v . '</td>';
                    }
                }
                if ($show_delete) {$body .= <<<STR
                        <td><button class="btn btn-xs btn-danger" onClick="deleteJsonColumnData({$delete_data_info["row_id_val"]},'{$by_json_key}','{$delete_data_info["table"]}',{$val[$by_json_key]},'{$delete_data_info["json_column_name"]}','{$delete_data_info["delete_url"]}')"><i class="bx bx-trash"></i></button></td>
                        STR;
                }

                $body .= '</tr>';

            }

            $str = '<div class="table-responsive">
              <table class="table table-bordered" >
              <thead>
              ' . $header . '
              </thead>
              <tbody>' . $body . '</tbody>
              </table>
              </div>';
            return $str;
        }
    } else {
        return '';
    }

}
function showArrayInColumnPlainText($ar)
{

    $str = '';
    if (is_array($ar)) {
        //   dd($ar);

        $keys = array_keys($ar[0]);
        foreach ($ar as $item) {
            foreach ($keys as $k) {

                $str .= $k . '-' . $item[$k] . ',';
            }

        }

    }
    return $str;

}
function fieldExist($model, $field_name, $value)
{
    $mod = app("App\\Models\\$model");
    return $mod->where($field_name, $value)->exists();
}
/***Storage app folder default location for storeAS */
function storeSingleFile($folder, $filerequest, $generateThumbnail = false)
{
    $filenameWithExt = $filerequest->getClientOriginalName();
    $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
    $extension = $filerequest->getClientOriginalExtension();
    $filename = time();
    $fileNameToStore = $filename . '.' . $extension;
    $path = $filerequest->storeAs('public/' . $folder, $fileNameToStore);
    // dd(storage_path('app/public/' . $folder.'/'.$fileNameToStore));
    ImageOptimizer::optimize(storage_path('app/public/' . $folder . '/' . $fileNameToStore));
    if ($generateThumbnail) {
        generateThumbnail($filerequest, $folder, getThumbnailDimensions(), $filename, $extension);
    }
    return $fileNameToStore;
}
function getValidation()
{
    return [
        (object) ['label' => 'Required', 'value' => 'required'],
        (object) ['label' => 'Image', 'value' => 'image'],
        (object) ['label' => 'Numeric', 'value' => 'numeric'],
        (object) ['label' => 'Nullable', 'value' => 'nullable'],
        (object) ['label' => 'String', 'value' => 'string'],
        (object) ['label' => 'Email', 'value' => 'email'],
        (object) ['label' => 'Sometimes', 'value' => 'sometimes'],
    ];
}
function getInputs()
{
    return [
        (object) ['label' => 'Text', 'value' => 'text'],
        (object) ['label' => 'Date', 'value' => 'date'],
        (object) ['label' => 'DateTimeLocal', 'value' => 'datetime-local'],
        (object) ['label' => 'Email', 'value' => 'email'],
        (object) ['label' => 'Textarea', 'value' => 'textarea'],
        (object) ['label' => 'Number', 'value' => 'number'],
        (object) ['label' => 'File', 'value' => 'file'],
        (object) ['label' => 'Select', 'value' => 'select'],
        (object) ['label' => 'Radio', 'value' => 'radio'],
        (object) ['label' => 'Checkbox', 'value' => 'checkbox'],

    ];
}
function getThumbnailDimensions()
{
    return [
        'tiny' => ['width' => 50, 'height' => 50],
        'small' => ['width' => 150, 'height' => 93],
        'medium' => ['width' => 300, 'height' => 185],
        'large' => ['width' => 550, 'height' => 340],
    ];
}
function storeMultipleFile($folder, $filerequest, $imagemodel, $parent_id, $parent_key_fieldname, $generate_thumbnail = false)
{
    $mod = app("App\\Models\\$imagemodel");
    $files = $filerequest;
    $i = 0;
    $ar_files = [];
    $data = [];
    foreach ($files as $file) {
        ++$i;
        $filenameWithExt = $file->getClientOriginalName();
        $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
        $extension = $file->getClientOriginalExtension();
        $filename = time();
        $fileNameToStore = $filename . '.' . $extension;
        $path = $file->storeAs('public/' . $folder, $fileNameToStore);
        if ($generate_thumbnail) {
            $variant_path = storage_path('app\\' . $folder . '\\thumbnail');
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);

            }
            generateThumbnail($file, $folder, getThumbnailDimensions(), $filename, $extension);
        }
        array_push($ar_files, $fileNameToStore);
        //  dd($ar_files);
        $data[] = [
            'name' => $fileNameToStore,
            '' . $parent_key_fieldname . '' => $parent_id, 'created_at' => date("Y-m-d H:i:s")];

    }
    $mod->insert($data);
    return $ar_files;
}
function generateThumbnail(
    $image_request, $folder,
    $dimensions,
    $original_file_name_without_ext,
    $original_file_ext
) {

    //$filename = pathinfo($filenamewithextension, PATHINFO_FILENAME);
    $filename = $original_file_name_without_ext;

    //get file extension
    $extension = $original_file_ext;

    //small thumbnail name
    $tinythumbnail = $filename . '_tiny.' . $extension;
    $smallthumbnail = $filename . '_small.' . $extension;

    //medium thumbnail name
    $mediumthumbnail = $filename . '_medium.' . $extension;

    //large thumbnail name
    $largethumbnail = $filename . '_large.' . $extension;

    //Upload File
    $base_path = $folder . '/thumbnail';
    $image_request->storeAs('public/' . $base_path, $tinythumbnail);

    $image_request->storeAs('public/' . $base_path, $smallthumbnail);
    $image_request->storeAs('public/' . $base_path, $mediumthumbnail);
    $image_request->storeAs('public/' . $base_path, $largethumbnail);

    $tinythumbnailpath = public_path('storage/' . $base_path . '/' . $tinythumbnail);
    createThumbnail($tinythumbnailpath, $dimensions['tiny']['width'], $dimensions['tiny']['height']);

    //create small thumbnail
    $smallthumbnailpath = public_path('storage/' . $base_path . '/' . $smallthumbnail);
    createThumbnail($smallthumbnailpath, $dimensions['small']['width'], $dimensions['small']['height']);

    //create medium thumbnail
    $mediumthumbnailpath = public_path('storage/' . $base_path . '/' . $mediumthumbnail);
    createThumbnail($mediumthumbnailpath, $dimensions['medium']['width'], $dimensions['medium']['height']);

    //create large thumbnail
    $largethumbnailpath = public_path('storage/' . $base_path . '/' . $largethumbnail);
    createThumbnail($largethumbnailpath, $dimensions['large']['width'], $dimensions['large']['height']);
    // return $filenametostore;
}
function createThumbnail($path, $width, $height)
{
    $img = Image::make($path)->resize($width, $height, function ($constraint) {
        $constraint->aspectRatio();
    });
    $img->save($path);
}
function createResponse($success, $message, $redirect_url = null)
{
    return response()->json(['success' => $success, 'message' => $message, 'redirect_url' => $redirect_url]);

}
function isPlainArray($array)
{
    $keys = array_keys($array);

    if (!is_array($array[$keys[0]])) {
        // associative array
        return true;
    } else {
        // sequential array
        return false;
    }
}
function isArrayEmpty($ar)
{

    $keys = array_keys($ar[0]);

    $is_empty = false;

    foreach ($keys as $key) {
        if (empty($ar[0][$key])) {
            $is_empty = true;
        } else {
            $is_empty = false;
            break;
        }

    }

    return $is_empty;
}
function getTableNameFromImageFieldList($list, $fieldname)
{

    $table_name = null;
    if (count($list) > 0) {
        foreach ($list as $item) {
            if ($item['field_name'] == $fieldname) {
                $table_name = !empty($item['table_name']) ? $item['table_name'] : '';

                break;
            }
        }
    }
    return $table_name;
}
function deleteSingleFileFromRelatedTable($folder, $fileid, $filemodel)
{
    $mod = app("App\\Models\\$filemodel");
    $filerow = $mod->findOrFail($fileid);
    $path = storage_path('app/public/' . $folder . '/' . $filerow->name);
    if (\File::exists($path)) {
        unlink($path);
        $thumbs = getThumbnailsFromImage($filerow->name);
        foreach ($thumbs as $p) {
            $path = storage_path('app/public/' . $folder . '/thumbnail/' . $p);
            if (\File::exists($path)) {
                unlink($path);
            }
        }

    }

}
function deleteAllFilesFromRelatedTable($folder, $parent_field_name, $parent_id, $filemodel)
{
    $mod = app("App\\Models\\$filemodel");
    $rows = $mod->where($parent_field_name, $parent_id);
    if ($rows->count() > 0) {
        foreach ($rows as $t) {
            $path = storage_path('app/public/' . $folder . '/' . $t->name);
            if (\File::exists($path)) {
                unlink($path);
                $thumbs = getThumbnailsFromImage($t->name);
                foreach ($thumbs as $p) {
                    $path = storage_path('app/public/' . $folder . '/thumbnail/' . $p);
                    if (\File::exists($path)) {
                        unlink($path);
                    }
                }
            }

        }

    }
}
function deleteSingleFileOwnTable($folder, $model, $model_field, $rowid)
{
    $mod = app("App\\Models\\$model");
    $row = $mod->findOrFail($rowid);
    $path = storage_path('app/public/' . $folder . '/' . $row->{$model_field});
    $mod->findOrFail($rowid)->update(['' . $model_field . '' => null]);
    if (\File::exists($path)) {
        unlink($path);
        $thumbs = getThumbnailsFromImage($row->{$model_field});
        foreach ($thumbs as $p) {
            $path = storage_path('app/public/' . $folder . '/thumbnail/' . $p);
            if (\File::exists($path)) {
                unlink($path);
            }
        }
    }

}
function getImageList($id, $image_model, $parent_field_name)
{
    $model = "App\\Models\\$image_model";
    return $model::where($parent_field_name, $id)->get(['id', 'name']);
}
function getTableNameFromModel($model)
{
    $model_class = app("\App\Models" . '\\' . $model);
    return $model_class->getTable();
}
function getFieldValuesFromModelAsArray($model, $field, $where = [])
{
    $model_class = "\App\Models" . '\\' . $model;
    $lists = $model_class::query();
    if (count($where) > 0) {
        $lists = $lists->where('status', 'Active')->where($where);
    }
    $lists = $lists->get([$field]);

    $list4 = [];
    foreach ($lists as $list) {
        $list4[] = $list[$field];

    }
    return $list4;
}
function getRadioOptions($model, $where = [], $by_field = 'name')
{
    $model_class = "\App\Models" . '\\' . $model;
    $lists = $model_class::query();
    if (count($where) > 0) {
        $lists = $lists->where('status', 'Active')->where($where);
    }
    $field_to_get = !empty($by_field) ? $by_field : 'name';
    $lists = $lists->get(['id', $field_to_get]);
    $alist = [];
    foreach ($lists as $list) {
        $ar = (object) ['label' => $list[$field_to_get], 'value' => $list['id']];
        array_push($alist, $ar);
    }
    return $alist;
}
function getListFromIndexArray($arr = []) /* for optinos in select not from model but from an array liek ['apple','mango']*/
{

    $list3 = [];
    foreach ($arr as $item) {
        $ar = (object) ['id' => $item, 'name' => $item];
        array_push($list3, $ar);
    }
    return $list3;
}
function getListFromIndexArrayForRadio($arr = []) /* for optinos in select not from model but from an array liek ['apple','mango']*/
{

    $list3 = [];
    foreach ($arr as $item) {
        $ar = (object) ['label' => $item, 'value' => $item];
        array_push($list3, $ar);
    }
    return $list3;
}
function getList($model, $where = [], $by_field = 'name', $append_column = '')
{
    $model_class = "\App\Models" . '\\' . trim($model);
    $lists = $model_class::query();
    if (count($where) > 0) {
        $lists = $lists->where($where);
    }
    $lists = $lists->get(['id', $by_field]);

    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list['id'], 'name' => $list[$by_field] . (!empty($append_column) ? '(' . $list[$append_column] . ')' : '')];
        array_push($list2, $ar);
    }
    return $list2;
}
function getListAssignedProduct()
{
    $store = \DB::table('stores')->whereOwnerId(auth()->id())->first();
    $lists = \App\Models\StoreAssignedProductStock::with('product:id,name')->whereStoreId($store->id)->get();

    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list->product_id, 'name' => $list->product->name . ' (' . $list->current_quantity . ')'];
        array_push($list2, $ar);
    }
    return $list2;
}
function getListProductWithQty()
{

    $lists = \App\Models\AdminProductStock::with('product:id,name')->get();

    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list->product_id, 'name' => $list->product->name . ' (' . $list->current_quantity . ')'];
        array_push($list2, $ar);
    }
    return $list2;
}

function getListMaterialWithQty()
{

    $lists = \App\Models\MaterialStock::with('material:id,name')->get();

    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list->material_id, 'name' => $list->material->name . ' (' . $list->current_stock . ')'];
        array_push($list2, $ar);
    }
    return $list2;
}

function getListWithRoles($role = 'name')
{

    $lists = \App\Models\User::role($role)->get(['name', 'id'])->toArray();
//dd($lists);
    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list['id'], 'name' => $list['name']];
        array_push($list2, $ar);
    }
    return $list2;
}

function getListOnlyNonIdValue($model, $where = [], $by_field = 'name')
{
    $model_class = "\App\Models" . '\\' . $model;

    $lists = $model_class::query();
    if (count($where) > 0) {
        $lists = $lists->where($where);
    }
    $lists = $lists->pluck($by_field)->toArray();

    return $lists;
}
function getListWithSameIdAndName($model, $where = [], $by_field = 'name')
{
    $model_class = "\App\Models" . '\\' . $model;
    $lists = $model_class::query();
    if (count($where) > 0) {
        $lists = $lists->where('status', 'Active')->where($where);
    }
    $lists = $lists->get(['id', $by_field]);

    $list2 = [];
    foreach ($lists as $list) {
        $ar = (object) ['id' => $list[$by_field], 'name' => $list[$by_field]];
        array_push($list2, $ar);
    }
    return $list2;

}

/******remove below thing any time  */

function getValOfArraykey($ar, $key, $is_array = true)
{
    return isset($ar[$key]) ? $ar[$key] : ($is_array ? [] : null);
}

function isThisATableColumn($table, $field)
{
    $fields_ar = \Illuminate\Support\Facades\Schema::getColumnListing($table);
    return in_array($field, $fields_ar);

}

function isIndexedArray($ar)
{

    return !is_array($ar[0]);
}
function getColumnType($table, $column)
{
    \Schema::getColumnType($table, $column);
}
function isFieldInRelationsArray($rel_ar, $field)
{
    $value_fetchable_field = str_contains($field, '_id') ? explode('_', $field)[0] : $field;
    return in_array($value_fetchable_field, array_column($rel_ar, 'name'));
}

function formatDefaultValueForSelect($model_relations, $model, $field, $is_multiple, $get_json_by_key_for_show_in_default = 'name')
{

    $table = $model->getTable();
    $value_fetchable_field = str_contains($field, '_id') ? explode('_', $field)[0] : $field;
    // dd($field);
    $field_type = getColumnType($table, $field);
    if ($is_multiple) {
        $field_value = ($field_type == 'json' || $field_type == 'Json') ? json_decode($model->{$value_fetchable_field}, true) : $model->{$value_fetchable_field};
        $isTableColumn = isThisATableColumn($table, $field);
        if ($isTableColumn) {
            return isIndexedArray($field_value) ? $field_value : (isFieldInRelationsArray($model_relations, $field) ? array_column($field_value, 'id') : array_column($field_value, $get_json_by_key_for_show_in_default));
        } else {
            return $model->{$value_fetchable_field} ? array_column($model->{$value_fetchable_field}->toArray(), 'id') : [];
        }
    } else {
        return $model->{$value_fetchable_field};
    }
    function formatDefaultValueForCheckbox($model, $field)
    {

        return $model->{$field} ? json_decode($model->{$field}, true) : [];

    }

}
// function showRelationalColumn($model_relations, $model, $field)
// {

//     $table = $model->getTable();
//     $value_fetchable_field = str_contains($field, '_id') ? explode('_', $field)[0] : $field;
//    $resp=null;
//    $isTableColumn = isThisATableColumn($table, $field);
//    if( $isTableColumn){
//      $field_type = getColumnType($table, $field);
//       $field_value= json_decode($model->{$value_fetchable_field}, true);
//    return isIndexedArray($field_value) ? $field_value : (isFieldInRelationsArray($model_relations, $value_fetchable_field) ? array_column($field_value, $get_json_by_key_for_show_in_default) : array_column($field_value, $get_json_by_key_for_show_in_default));

//    }

//     if ($field_type == 'json' || $field_type == 'Json') {
//         $field_value= json_decode($model->{$value_fetchable_field}, true);
//         $isTableColumn = isThisATableColumn($table, $field);
//         if ($isTableColumn) {
//             return isIndexedArray($field_value) ? $field_value : (isFieldInRelationsArray($model_relations, $value_fetchable_field) ? array_column($field_value, $get_json_by_key_for_show_in_default) : array_column($field_value, $get_json_by_key_for_show_in_default));
//         } else {
//             return $model->{$field} ? array_column($model->{$field}->toArray(), 'id') : [];
//         }
//     } else {
//         return $model->{$value_fetchable_field};
//     }
//     function formatDefaultValueForCheckbox($model, $field)
//     {

//         return $model->{$field} ? json_decode($model->{$field}, true) : [];

//     }

// }

function formatDefaultValueForEdit($model, $field, $is_multiple = false)
{

    if ($is_multiple) {
        return json_decode($model->{$field}, true);

    } else {
        return $model->{$field};
    }
}
function getTableValueForManyTypeRelation($model, $field)
{
    return $model->{$field} ? $model->{$field}->pluck('id') : [];
}

function formatDefaultValueForCheckbox($model, $field)
{

    return $model->{$field} ? json_decode($model->{$field}, true) : [];

}
function is_admin()
{

    return auth()->user()->hasRole(['Admin']);
}
function can($permission)
{
    // dd(auth()->user());
    return (auth()->user()->hasRole(['Admin'])) || (auth()->user()->can($permission));
}
/******Monthly weekly daily recors for chart */
function getDailyRecord($table, $date_column = 'created_at', $to_do = 'sum', $cond = "", $column_for_sum = "amount", $for_days = 7)
{
    $perday_records = null;
    if ($to_do == 'sum') {
        $query = "SELECT SUM(`" . $column_for_sum . "`) AS total, Date(`" . $date_column . "`) AS d FROM  " . $table . " WHERE Date(`" . $date_column . "`) BETWEEN ADDDATE(NOW(),-" . $for_days . ")
        AND NOW()  " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY Date(`" . $date_column . "`) ORDER BY DATE(`" . $date_column . "`) DESC";
    } else {
        $query = "SELECT COUNT(*) AS c, Date(`" . $date_column . "`) AS d FROM  " . $table . " WHERE Date(`" . $date_column . "`)
         BETWEEN ADDDATE(NOW(),-" . $for_days . ") AND NOW()  " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY Date(`" . $date_column . "`) ORDER BY DATE(`" . $date_column . "`) DESC";
    }

    $perday_records = \DB::select($query);
    $perday_records = array_map(function ($v) {
        return (array) $v;
    }, $perday_records);
    return ['val' => array_column($perday_records, $to_do == 'sum' ? 'total' : 'c'), 'datetime' => array_column($perday_records, 'd')];

}
function getMonthlyRecord($table, $date_column = 'created_at', $to_do = 'sum', $cond = "", $column_for_sum = "amount")
{
    $month_ar = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    $monthly_records = null;
    if ($to_do == 'sum') {
        $query = "SELECT SUM(`" . $column_for_sum . "`) AS total, MONTH(`" . $date_column . "`) AS m FROM  " . $table . "
         WHERE YEAR(`" . $date_column . "`) =YEAR(NOW())  " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY MONTH(`" . $date_column . "`)";
    } else {
        $query = "SELECT COUNT(*) AS c, MONTH(`" . $date_column . "`) AS m FROM  " . $table . "
         WHERE YEAR(`" . $date_column . "`) =YEAR(NOW())  " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY MONTH(`" . $date_column . "`)";

    }

    $monthly_records = \DB::select($query);

    $monthly_records = array_map(function ($v) {
        $v->m = date("M", mktime(0, 0, 0, $v->m, 10));
        return (array) $v;
    }, $monthly_records);

    $monthly_records = collect($monthly_records)->pluck($to_do == 'sum' ? 'total' : 'c', 'm')->toArray();
    $monthly_records_val = [];
    foreach ($month_ar as $m) {
        if (isset($monthly_records[$m])) {
            $monthly_records_val[ucfirst($m)] = $monthly_records[$m];
        } elseif (isset($monthly_records[ucfirst($m)])) {
            $monthly_records_val[ucfirst($m)] = $monthly_records[ucfirst($m)];

        } else {
            $monthly_records_val[ucfirst($m)] = 0.0;
        }
    }

    return array_values($monthly_records_val);

}
function getWeeklyRecord($table, $date_column = 'created_at', $to_do = 'sum', $cond = "", $column_for_sum = "amount", $no_weeks = 4)
{

    $monthly_records = null;
    if ($to_do == 'sum') {
        $query = "SELECT SUM(`" . $column_for_sum . "`) AS total, WEEK(`" . $date_column . "`) AS w FROM  " . $table . "
         WHERE YEAR(`" . $date_column . "`) =YEAR(NOW())   AND  Date(`" . $date_column . "`) BETWEEN (NOW() - INTERVAL " . $no_weeks . " WEEK)
        AND NOW() " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY WEEK(`" . $date_column . "`) ORDER BY WEEK(`" . $date_column . "`) DESC";
    } else {
        $query = "SELECT COUNT(*) AS c, WEEK(`" . $date_column . "`) AS w FROM  " . $table . "
         WHERE YEAR(`" . $date_column . "`) =YEAR(NOW()) AND  Date(`" . $date_column . "`) BETWEEN (NOW() - INTERVAL " . $no_weeks . " WEEK)
        AND NOW()  " . (strlen($cond) > 1 ? "AND " . $cond : null) . " GROUP BY WEEK(`" . $date_column . "`) ORDER BY WEEK(`" . $date_column . "`) DESC";

    }

    //dd($query);
    $weekly_records = \DB::select($query);

    $weekly_records = collect($weekly_records)->pluck($to_do == 'sum' ? 'total' : 'c', 'w')->toArray();
    $weekly_records_val = [];
    $i = 1;
    foreach (array_keys($weekly_records) as $w) {
        if (isset($weekly_records[$w])) {
            $weekly_records_val[$i] = $weekly_records[$w];
        } else {
            $weekly_records_val[$i] = 0.0;
        }
        $i++;
    }

    return array_values($weekly_records_val);

}

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
    while ($i < $digits_length) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str[] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
        } else {
            $str[] = null;
        }

    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ucwords(($Rupees ? $Rupees . 'Rupees ' : '') . $paise) . 'Only';
}
function getCurrency()
{
    return '₹';

}
function getTableRecordSum($table, $where, $by_column)
{
    $q = \DB::table($table);
    if (count($where) > 0) {
        $q = $q->where($where);
    }
    return $q->sum($by_column);
}
function getTableRecordCount($table, $where)
{
    $q = \DB::table($table);
    if (count($where) > 0) {
        $q = $q->where($where);
    }
    return $q->count();
}
function getNonSubjectType()
{
    return ['PT', 'Sports', 'Prayer', 'Lunch', 'Music', 'PTM', 'Other'];
}
function getCLassSubjects($class_id)
{
    $subjects_row = \DB::table('school_classes')->whereId($class_id)->first();
    if (is_null($subjects_row->stream_id)) {
        return null;
    } else {
        $stream_row = \DB::table('streams')->whereId($subjects_row->stream_id)->first();
        return $stream_row->subjects ? json_decode($stream_row->subjects) : null;

    }

}
function studentInfo($student)
{
    $str = '<div class="table-responsive">
                    <table class="table table-bordered">
                       <tbody>
                         <tr>
                           <th>Full Name</th><td>' . $student->full_name . '</td>
                         </tr>
                         <tr>
                           <th>Father Name</th><td>' . $student->father_name . '</td>
                         </tr>
                         <tr>
                           <th>Admission No.</th><td>' . $student->admission_number . '</td>
                         </tr>
                         <tr>
                           <th>Address</th><td>' . $student->address . '</td>
                         </tr>
                       </tbody>
                    </table>
                    </div>';
    return $str;
}
function randomPassword()
{
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
function differenceInHours($startdate, $enddate)
{
    $starttimestamp = strtotime($startdate);
    $endtimestamp = strtotime($enddate);
    $difference = abs($endtimestamp - $starttimestamp) / 3600;
    return $difference;
}
function differenceInDays($startdate, $enddate)
{
    $starttimestamp = date_create($startdate);
    $endtimestamp = date_create($enddate);
    $difference = abs($endtimestamp - $starttimestamp) / 3600;
    return $difference;
}
function displayDates($date1, $date2)
{
    $dates = array();
    $current = strtotime($date1);
    $date2 = strtotime($date2);
    $stepVal = '+1 day';
    while ($current <= $date2) {
        $dates[] = date($format, $current);
        $current = strtotime($stepVal, $current);
    }
    return $dates;
}
function formattedPaginatedApiResponse($paginated_data)
{
    $list = $paginated_data->toArray();
    $ar_price = !empty($list['data']) ? array_column($list['data'], 'price') : [];
    $minPrice = 0;
    $maxPrice = 0;
    if (!empty($ar_price)) {
        $minPrice = min($ar_price);
        $maxPrice = max($ar_price);
    }
    $resp = [];
    $resp['data'] = $list['data'];
    $resp['meta'] = [
        'prev_page' => $list['current_page'] <= 1 ? null : $list['current_page'] - 1,
        'next_page' => $list['current_page'] >= $list['last_page'] ? null : $list['current_page'] + 1,
        'last_page' => $list['last_page'],
        'per_page' => $list['per_page'],
        'total_pages' => $list['last_page'],
        'total_items' => $list['total'],
        'current_page' => $list['current_page'],
        'minPrice' => $minPrice,
        'maxPrice' => $maxPrice,
    ];
    return $resp;
}
function getThumbnailsFromImage($image_name)
{
    $filename = pathinfo($image_name, PATHINFO_FILENAME);
    $ext = pathinfo($image_name, PATHINFO_EXTENSION);
    return [
        'tiny' => $filename . '_tiny' . '.' . $ext,
        'small' => $filename . '_small' . '.' . $ext,
        'medium' => $filename . '_medium' . '.' . $ext,
        'large' => $filename . '_large' . '.' . $ext,
    ];
}
function gt($ar, $i, $s, $selected_id = null, )
{
    $i++;
    foreach ($ar as $k) {
        $selected = $selected_id == $k['id'] ? 'selected' : '';
        $s .= '<option ' . $selected . ' value="' . $k['id'] . '"> ' . str_repeat('-', $i) . $k['name'] . '</option>';

        $childs = \App\Models\Category::whereCategoryId($k['id'])->get()->toArray();
        if (count($childs) > 0) {
            $s = gt($childs, $i, $s, $selected_id);
        }

    }

    return $s;
}
function gt_multiple($ar, $i, $s, $selected_id)
{
    $i++;
    foreach ($ar as $k) {
        if ($k['id']) {
            $selected = ($k['id'] && in_array($k['id'], $selected_id)) ? 'selected' : '';

            $s .= '<option ' . $selected . ' value="' . $k['id'] . '"> ' . str_repeat('-', $i) . $k['name'] . '</option>';

            $childs = \App\Models\Category::whereCategoryId($k['id'])->get()->toArray();
            if (count($childs) > 0) {

                $s = gt_multiple($childs, $i, $s, $selected_id);
            }
        }

    }

    return $s;
}
function gt1($ar, $final_ar)
{

    foreach ($ar as $k) {
        $final_ar[] = ['id' => $k['id'], 'name' => $k['name']];
        $childs = \App\Models\Category::whereCategoryId($k['id'])->get()->toArray();
        if (count($childs) > 0) {
            $final_ar = gt1($childs, $final_ar);
        }

    }

    return $final_ar;
}
function getRowFromCartItems($cart_items, $product_id)
{
    $item_row = null;
    foreach ($cart_items as $row) {
        if ($row->product_id == $product_id) {
            $item_row = $row;
            break;
        }
    }
    return $item_row;
}
function getCartAmountAfterIndividualDiscount()
{
    /* includes bulk discount and combo and product discount all ***/
    $cart_amount_without_offer = 0;
    $offerDiscount = 0.0; /**incldes above discount value***/
    $cart_net_amount = 0;
    foreach ($carts as $el) {
        $price = $el->price;
        $sale_price = $el->sale_price;
        $cart_amount_without_offer += $price * $el->qty;

        $total_saving_per_item = 0;
        $qty = $el->qty;
        $row_final_val = 0;
        //**this discount is on overall cost of item so no need to multiply by qty on discount just totalcost-discount */
        if ($el->discount_rules != null) {
            $rules = json_decode($el->discount_rules)[0];
            foreach ($rules as $rule) {
                if ($rule->discount_type != null && $rule->discount != null) {
                    if ($rule->has_range == 'No') {
                        /****1- Cart item qty can be greater than rule exact qty so jitna extra cart qty hai uspe normal
                         * discount column rule lagega taking into discount_applies_qty column into account */
                        $disc_for_exact_qty = $rule->discount_type == 'Flat'
                        ? $rule->discount
                        : ($price * $rule->discount / 100);
                        $offerDiscount += $disc_for_exact_qt * $rule->exact_qty;
                        $sale_price_for_the_exact_qty = $price - $disc_for_exact_qty;
                        $total_sale_price_for_exact_qty = $sale_price_for_the_exact_qty * $rule->exact_qty;
                        $total_sale_price_for_next_qty = 0; /***isme ek to wo ayega jo ki less than or equa lt discount_applies_qty column ke doosra wo jo isse xtra bache */
                        if ($qty > $rule->exact_qty) {
                            $remaining_qty = $qty - $rule->exact_qty;
                            $discount_applies_on_qty = $el->discount_applies_on_qty; /**discount_applies_qty clumn in cart item row */
                            $disc_for_the_next_qty = $el->discount_type != null && $el->discount != null
                            ? ($el->discount_type == 'Flat'
                                ? $el->discount
                                : ($price * $el->discount / 100))
                            : 0;
                            if ($disc_for_the_next_qty > 0) {
                                if (!$discount_applies_on_qty) {

                                    $offerDiscount += $disc_for_the_next_qty * ($remaining_qty);
                                    $sale_price_for_next_qty = $disc_for_the_next_qty > 0 ? $price - $disc_for_the_next_qty : $sale_price;
                                    $total_sale_price_for_next_qty = $sale_price_for_next_qty * ($remaining_qty);

                                } else {
                                    if ($remaining_qty > $discount_applies_on_qty) {
                                        $offerDiscount += $disc_for_the_next_qty * ($discount_applies_on_qty);
                                        $sale_price_for_discount_applies_qty = $price - $disc_for_the_next_qty;
                                        $total_sale_price_for_discount_applies_qty = $sale_price_for_discount_applies_qty * ($discount_applies_on_qty);
                                        $total_sale_price_after_discount_applies_qty = $sale_price * ($remaining_qty - $discount_applies_on_qt);
                                        $total_sale_price_for_next_qty = $total_sale_price_for_discount_applies_qty + $total_sale_price_after_discount_applies_qty;
                                    } else {
                                        $offerDiscount += $disc_for_the_next_qty * ($remaining_qty);
                                        $sale_price_for_next_qty = $disc_for_the_next_qty > 0 ? $price - $disc_for_the_next_qty : $sale_price;
                                        $total_sale_price_for_next_qty = $sale_price_for_next_qty * $remaining_qty;
                                    }
                                }
                            } else {
                                $total_sale_price_for_next_qty = $sale_price * ($remaining_qty);
                            }

                        }
                        $row_final_val = $total_sale_price_for_exact_qty + $total_sale_price_for_next_qty;
                        $cart_net_amount += $row_final_val;
                    } else {
                        $disc = $rule->discount_type == 'Flat'
                        ? $rule->discount
                        : ($price * $rule->discount / 100);
                        $offerDiscount += $disc * $rule->min_qty;
                        $sale_price = $price - $disc;
                        $total_sale_price = $sale_price * $rule->min_qty;
                        $cart_net_amount += $total_sale_price;
                    }

                }

            }

        } else {
            $discount_applies_on_qty = $el->discount_applies_on_qty;
            $disc = $el->discount_type != null && $el->discount != null
            ? ($el->discount_type == 'Flat'
                ? $el->discount
                : ($price * $el->discount / 100))
            : 0;
            if ($disc > 0) {
                if ($remaining_qty > $discount_applies_on_qty) {
                    $offerDiscount += $disc_for_the_next_qty * ($discount_applies_on_qty);
                    $sale_price_for_discount_applies_qty = $price - $disc_for_the_next_qty;
                    $total_sale_price_for_discount_applies_qty = $sale_price_for_discount_applies_qty * ($discount_applies_on_qty);
                    $total_sale_price_after_discount_applies_qty = $sale_price * ($remaining_qty - $discount_applies_on_qt);
                    $total_sale_price_for_next_qty = $total_sale_price_for_discount_applies_qty + $total_sale_price_after_discount_applies_qty;
                } else {
                    $offerDiscount += $disc_for_the_next_qty * ($remaining_qty);
                    $sale_price_for_next_qty = $disc_for_the_next_qty > 0 ? $price - $disc_for_the_next_qty : $sale_price;
                    $total_sale_price_for_next_qty = $sale_price_for_next_qty * $remaining_qty;
                }
            } else /***No disc it means selleing at sale_price column value */
            {
                $cart_net_amount += $sale_price * $el->qty;
            }

        }
        $individualItemOfferDiscount = $offerDiscount;
        $cart_amount_val += ($price * $el->qty) - $offerDiscount;
    }
    return ['cart_amount_before_discount' => $cart_amount_without_offer,
        'cart_net_amount' => $cart_net_amount, 'offer_discount' => $offerDiscount,
    ];
}
function getNetAmountAfterIndividualDiscountForSingleCartItem($el, $discount_rules)
{
    /* includes bulk discount and combo and product discount all ***/
    $cart_amount_without_offer = 0;
    $offerDiscount = 0.0; /**incldes above discount value***/
    $cart_net_amount = 0;

    $price = $el->price;
    $sale_price = $el->sale_price;
    $cart_amount_without_offer += $price * $el->qty;

    $total_saving_per_item = 0;
    $qty = $el->qty;
    $row_final_val = 0;
    //**this discount is on overall cost of item so no need to multiply by qty on discount just totalcost-discount */
    if (!empty($discount_rules)) {
        $rules = $discount_rules;
        foreach ($rules as $rule) {
            if ($rule['discount_type'] != null && $rule['discount'] != null) {
                if ($rule['has_range'] == 'No') {
                    /****1- Cart item qty can be greater than rule exact qty so jitna extra cart qty hai uspe normal
                     * discount column rule lagega taking into discount_applies_qty column into account */
                    $disc_for_exact_qty = $rule['discount_type'] == 'Flat'
                    ? $rule['discount']
                    : ($price * $rule['discount'] / 100);
                    $offerDiscount += $disc_for_exact_qty * $rule['exact_qty'];
                    $sale_price_for_the_exact_qty = $price - $disc_for_exact_qty;
                    $total_sale_price_for_exact_qty = $sale_price_for_the_exact_qty * $rule['exact_qty'];
                    $total_sale_price_for_next_qty = 0; /***isme ek to wo ayega jo ki less than or equa lt discount_applies_qty column ke doosra wo jo isse xtra bache */
                    if ($qty > $rule['exact_qty']) {
                        $remaining_qty = $qty - $rule['exact_qty'];
                         $disc_for_the_next_qty = $el->discount_type != null && $el->discount != null
                        ? ($el->discount_type == 'Flat'
                            ? $el->discount
                            : ($price * $el->discount / 100))
                        : 0;
                        if ($disc_for_the_next_qty > 0) {
                               $offerDiscount += $disc_for_the_next_qty * ($remaining_qty);
                                $sale_price_for_next_qty = $disc_for_the_next_qty > 0 ? $price - $disc_for_the_next_qty : $sale_price;
                                $total_sale_price_for_next_qty = $sale_price_for_next_qty * ($remaining_qty);

                            
                            
                        } else {
                            $total_sale_price_for_next_qty = $sale_price * ($remaining_qty);
                        }

                    }
                    $row_final_val = $total_sale_price_for_exact_qty + $total_sale_price_for_next_qty;
                    $cart_net_amount= $row_final_val;
                } else {
                    $disc = $rule['discount_type'] == 'Flat'
                    ? $rule->discount
                    : ($price * $rule['discount'] / 100);
                    $offerDiscount += $disc * $rule['min_qty'];
                    $sale_price = $price - $disc;
                    $total_sale_price = $sale_price * $rule['min_qty'];
                    $cart_net_amount= $total_sale_price;
                }

            }

        }

    } else {
       
            $offerDiscount = ($price-$sale_price) * ($qty);
            $cart_net_amount = $sale_price * $el->qty;
        

    }
   $total_tax=($cart_net_amount*($el->sgst+$el->cgst+$el->igst))/100;

    return ['net_cart_amount'=>$cart_net_amount+$total_tax,'total_discount'=>$offerDiscount,'total_tax'=>$total_tax];

}
