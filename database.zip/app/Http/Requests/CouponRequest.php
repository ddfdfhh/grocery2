<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CouponRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
    'coupon_code' => 'required',
    'customer_group_id' => 'nullable',
    'customer_usage_limit' => 'numeric',
    'details' => 'required',
    'discount' => 'required|numeric',
    'discount_type' => 'required',
    'end_date' => 'required',
    'free_shipping' => 'nullable',
    'minimum_order_amount' => 'numeric|nullable',
    'name' => 'required|string',
    'start_date' => 'required',
    'status' => 'string',
    'total_usage_limit' => 'numeric',
    'total_used_till_now' => 'numeric|nullable'
];
    }
}