<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContentSectionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
    'section_number' => 'required',
    'section_title' => 'nullable',
    
];
    }
}