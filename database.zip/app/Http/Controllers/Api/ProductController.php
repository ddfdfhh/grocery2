<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use \App\Models\Product;
use \Carbon\Carbon;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $r)
    {

        $category = $r->categroy_id;
        $orderByPrice = $r->has('orderByPrice') ? $r->orderByPrice : null;
        $orderByDiscount = $r->has('orderbyDiscount') ? $r->orderbyDiscount : null;
        $priceRange = $r->has('priceRange') ? json_decode(urldecode($r->priceRange), true) : [];
        //  dd(json_decode(urldecode($r->priceRange),true));
        $brands = $r->has('filterBybrands') ? json_decode($r->filterBybrands, true) : [];
        // Log::info('show for: {id}', ['id' => $category]);
        $bulk_discounts = \DB::table('bulk_discounts')->whereStatus('Active')
            ->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now())
            ->get();
        // dd($bulk_discounts->toArray());
        $category_dis = [];
        $prod_dis = [];
        $categories_with_offer = [];
        $products_with_offer = [];
        if (count($bulk_discounts->toArray()) > 0) {
            foreach ($bulk_discounts as $dis) {
                $categories = $dis->category_id ? json_decode($dis->category_id, true) : null;
                $products = $dis->product_id ? json_decode($dis->product_id, true) : null;
                if (!is_null($categories) && is_null($products)) {
                    foreach ($categories as $cat) {
                        $category_dis[$cat['id']] = [
                            'rule_name' => $dis->name,
                            'discount_type' => $dis->discount_type,
                            'discount' => $dis->discount,

                        ];
                    }
                } else {
                    if (!is_null($products)) {
                        foreach ($products as $prod) {
                            $prod_dis[$prod['id']] = [
                                'rule_name' => $dis->name,
                                'discount_type' => $dis->discount_type,
                                'discount' => $dis->discount,

                            ];
                        }
                    }
                }

            }
            $categories_with_offer = array_keys($category_dis);
            $products_with_offer = array_keys($prod_dis);
        }

        $per_page = 10;

        $list = Product::with(['brand:id,name', 'category:id,name', 'variants'])->
            when(!is_null($category), function ($query) use ($category) {
            return $query->where('category_id', $category);
        })->when(!empty($brands), function ($query) use ($brands) {
            return $query->whereHas('brand', function ($q1) {
                $q1->whereIn('name', $brands);
            });
        })->when(!empty($priceRange), function ($query) use ($priceRange) {
            return $query->where('price', '>=', $priceRange['min'])
                ->where('price', '<=', $priceRange['max']);
        })->when(!empty($orderByPrice), function ($query) use ($orderByPrice) {
            return $query->orderBy('price', $orderByPrice);

        })->paginate($per_page);

        $dimensions = getThumbnailDimensions();
        $list->getCollection()->transform(function ($r) use ($categories_with_offer, $products_with_offer, $category_dis, $prod_dis) {
            if (!empty($categories_with_offer)) {
                if (in_array($r->category_id, $categories_with_offer)) {
                    if (isset($category_dis[$r->category_id])) {
                        $r->discount_type = $category_dis[$r->category_id]['discount_type'];
                        $r->discount = $category_dis[$r->category_id]['discount'];
                    }
                }
            }
            if (!empty($products_with_offer)) {

                if (in_array($r->id, $products_with_offer)) {
                    if (isset($prod_dis[$r->id])) {
                        $r->discount_type = $prod_dis[$r->id]['discount_type'];
                        $r->discount = $prod_dis[$r->id]['discount'];
                    }
                }
            }

            // unset($r->category_id);
            unset($r->vendor_id);
            unset($r->brand_id);
            $r->brand_name = $r->brand ? $r->brand->name : '';
            $r->category_name = $r->category ? $r->category->name : '';
            unset($r->brand);
            unset($r->category);
            $r->attributes = json_decode($r->attributes, true);
            $r->thumbnail = new \stdClass;
            if ($r->image) {
                $r->thumbnail = getThumbnailsFromImage($r->image);
            }
            /**update sale price from here  */
            if (count($r->variants) == 0) {
                $discount = $r->discount_type != null
                ? ($r->discount_type == 'Flat'
                    ? $r->discount
                    : ($r->price * $r->discount / 100))
                : 0;

                $r->sale_price = $discount > 0 ? $r->price - $discount : $r->sale_price;
            } else {
                $variants = $r->variants;
             
                /**update variants for discounted sale price */
                $r->variants= $r->variants->map(function ($el) use ($r) {
                    // $el->thumbnail = new \stdClass;
                    // if ($el->image) {
                    //     $el->thumbnail = getThumbnailsFromImage($v->image);
                    // }
                    $discount = $r->discount_type != null
                    ? ($r->discount_type == 'Flat'
                        ? $r->discount
                        : ($r->price * $r->discount / 100))
                    : 0;

                    $own_discount = $el->discount_type != null
                    ? ($el->discount_type == 'Flat'
                        ? $el->discount
                        : ($el->price * $el->discount / 100))
                    : 0;
                    $el->sale_price = $own_discount > 0
                    ? $el->price - $own_discount
                    : ($discount > 0 ? $el->price - $discount : $el->sale_price);
                    $el->sale_price=floatVal($el->sale_price);
                    return $el;

                });
               // dd($r->variants[0]->toArray());
                $r->price = $r->variants[0]->price;
                $r->sale_price = floatVal($r->variants[0]->sale_price);
            }
            if ($r->sgst == null) {
                if ($r->category->sgst > 0) {
                    $r->sgst = $r->category->sgst;
                }
                elseif(!is_null($setting) && $setting->sgst>0)
                {
                    $r->sgst =$setting->sgst;
                }
            }
            if ($r->cgst == null) {
                if ($r->category->cgst > 0) {
                    $product->cgst = $r->category->cgst;
                }
                elseif(!is_null($setting) && $setting->cgst>0)
                {
                    $r->cgst =$setting->cgst;
                }
            }
            if ($r->igst == null) {
                if ($r->category->igst > 0) {
                    $rr->igst = $r->category->igst;
                }
            }
            return $r;
        });

        return response()->json(formattedPaginatedApiResponse($list), 200);
    }

    public function show($id)
    {
        $setting=\DB::table('settings')->first();
        $product = Product::with(['brand:id,name', 'category:id,name,sgst,cgst,igst', 'variants', 'images'])->first();
        $bulk_discounts = \DB::table('bulk_discounts')->whereStatus('Active')
            ->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now())
            ->get();
        $category_dis = [];
        $prod_dis = [];
        $categories_with_offer = [];
        $products_with_offer = [];
        if (count($bulk_discounts->toArray()) > 0) {
            foreach ($bulk_discounts as $dis) {
                $categories = $dis->category_id ? json_decode($dis->category_id, true) : null;
                $products = $dis->product_id ? json_decode($dis->product_id, true) : null;
                if (!is_null($categories) && is_null($products)) {
                    foreach ($categories as $cat) {
                        $category_dis[$cat['id']] = [
                            'rule_name' => $dis->name,
                            'discount_type' => $dis->discount_type,
                            'discount' => $dis->discount,

                        ];
                    }
                } else {
                    if (!is_null($products)) {
                        foreach ($products as $prod) {
                            $prod_dis[$prod['id']] = [
                                'rule_name' => $dis->name,
                                'discount_type' => $dis->discount_type,
                                'discount' => $dis->discount,

                            ];
                        }
                    }
                }

            }
            $categories_with_offer = array_keys($category_dis);
            $products_with_offer = array_keys($prod_dis);
        }

        $dimensions = getThumbnailDimensions();

        if (!empty($categories_with_offer)) {
            if (in_array($product->category_id, $categories_with_offer)) {
                if (isset($category_dis[$product->category_id])) {
                    $product->discount_type = $category_dis[$product->category_id]['discount_type'];
                    $product->discount = $category_dis[$product->category_id]['discount'];
                }
            }
        }
        if (!empty($products_with_offer)) {
            if (in_array($product->id, $products_with_offer)) {
                if (isset($prod_dis[$product->id])) {
                    $product->discount_type = $prod_dis[$product->id]['discount_type'];
                    $product->discount = $prod_dis[$product->id]['discount'];
                }
            }
        }
        if (count($product->variants) == 0) {
            $discount = $product->discount_type != null
            ? ($product->discount_type == 'Flat'
                ? $product->discount
                : ($product->price * $product->discount / 100))
            : 0;

            $product->sale_price = $discount > 0 ? $product->price - $discount : $product->sale_price;
        } else {
          
            /**update variants for discounted sale price */
            $product->variants= $product->variants->map(function ($el) use ($product) {
                $discount = $product->discount_type != null
                ? ($product->discount_type == 'Flat'
                    ? $product->discount
                    : ($product->price * $product->discount / 100))
                : 0;

                $own_discount = $el->discount_type != null
                ? ($el->discount_type == 'Flat'
                    ? $el->discount
                    : ($el->price * $el->discount / 100))
                : 0;
                $el->sale_price = $own_discount > 0
                ? $el->price - $own_discount
                : ($discount > 0 ? $el->price - $discount : $el->sale_price);
                $el->sale_price=floatVal($el->sale_price);
                return $el;

            });
         
            $product->price = $product->variants[0]->price;
            $product->sale_price =floatVal($product->variants[0]->sale_price);
        }
        unset($product->vendor_id);
        unset($product->brand_id);
        $product->brand_name = $product->brand ? $product->brand->name : '';
        $product->category_name = $product->category ? $product->category->name : '';
        unset($product->brand);
        unset($product->category);
        $product->attributes = json_decode($product->attributes, true);
        $product->thumbnail = new \stdClass;
        if ($product->image) {
            $product->thumbnail = getThumbnailsFromImage($product->image);
        }

        foreach ($product->images as $img) {
            $img->thumbnail = getThumbnailsFromImage($img->name);
        }
        if ($product->sgst == null) {
            if ($product->category->sgst > 0) {
                $product->sgst = $product->category->sgst;
            }
            elseif(!is_null($setting) && $setting->sgst>0)
            {
                $product->sgst =$setting->sgst;
            }
        }
        if ($product->cgst == null) {
            if ($product->category->cgst > 0) {
                $product->cgst = $product->category->cgst;
            }
            elseif(!is_null($setting) && $setting->cgst>0)
            {
                $product->cgst =$setting->cgst;
            }
        }
        if ($product->igst == null) {
            if ($product->category->igst > 0) {
                $product->igst = $product->category->igst;
            }
        }
        return response()->json(['data' => $product], 200);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function featured()
    {
        $list = Product::with(['images', 'variants', 'variants.images'])->limit(10)->get();
        return createResponse(true, json_encode($list));
    }
    public function search(Request $r)
    {
        $search_string = trim($r->search_string);
        // dd($search_string);
        // $result=\App\Models\Product::whereName('')
        $query = \App\Models\Product::with('category:id,name')->where('name', 'like', '%' . $search_string . '%')->get();
        //$products=[];

        foreach ($query as $t) {
            $t->cat_name = $t->category->name;
            unset($t->category);
            $r->thumbnail = new \stdClass;
            if ($t->image) {
                $thum = getThumbnailsFromImage($t->image);
                $t->thumbnail = !empty($thum) ? $thum['tiny'] : '';
            }

        }
        return response()->json(['data' => $query], 200);

    }

}
