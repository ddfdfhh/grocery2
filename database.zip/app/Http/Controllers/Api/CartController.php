<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use \Carbon\Carbon;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $r)
    {
        Log::info("cart init index called");
        $email = $r->email;
        $phone = $r->phone;

        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $user_id = $user->id;
        $carts = \DB::table('carts')->whereUserId($user_id)->get()->toArray();

        return response()->json(['data' => $carts], 200);
    }

    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    public function store(Request $r)
    {

        //.dd('hi');

        $post = $r->all();
        $email = $r->email;
        $phone = $r->phone;

        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $user_id = $user->id;
        $cart_id = $post['id'];

        Log::info('cart data {id}', ['id' => json_encode($r->all())]);
        if (!empty($cart_id)) {
            $row = Cart::whereId($cart_id)->first();
            if ($post['qty'] == 0 || empty($post['qty'])) {
                $row->delete();
            } else {
                $row->update([
                    'qty' => $r->qty]);
                 $row->refresh();
                $rules = $this->getProductRules($row);
                $p = getNetAmountAfterIndividualDiscountForSingleCartItem($row, $rules);
                $row->update([
                   
                    'discount_rules' => !empty($rules) ? json_encode($rules) : null,
                    'net_cart_amount' => $p['net_cart_amount'], 'total_discount' => $p['total_discount'],
                    'product_discount_offer_detail' => !empty($rules) ? $rules[0]['offer_text'] : null,
                    'total_tax' => $p['total_tax'],
                ]);
            }

        } else {

            $post['is_combo'] = 'No';

            $latest_cart_item = Cart::whereUserId($user_id)->latest()->first();
            $cart_session_id = is_null($latest_cart_item) ? $user_id . uniqid() : $latest_cart_item->cart_session_id;
            $post['cart_session_id'] = $cart_session_id;
            $post['user_id'] = $user_id;
            $post['cart_net_amount'] = 0;
            $post['total_discount'] = 0;
            $post['total_tax'] = 0;
            $row = Cart::create($post);
            // $row->qty = $row->qty - 1;
            $rules = $this->getProductRules($row);

            $p = getNetAmountAfterIndividualDiscountForSingleCartItem($row, $rules);
           
            $row->update([
                // 'qty' => $row->qty + 1,
                'discount_rules' => !empty($rules) ? json_encode($rules) : null,
                'net_cart_amount' => $p['net_cart_amount'], 'total_discount' => $p['total_discount'],
                'product_discount_offer_detail' => !empty($rules) ? $rules[0]['offer_text'] :null,
                'total_tax' => $p['total_tax'],
            ]);

        }
        $combo_product_as_offer = $this->getComboProductsOffer($row->cart_session_id);
        $cart_items = \DB::table('carts')->whereCartSessionId($row->cart_session_id)->whereUserId($user_id)->get();
        $cart_product_ids = array_column($cart_items->toArray(), 'product_id');
        if (!empty($combo_product_as_offer)) {
            Log::info("combo {id}", ['id' => $combo_product_as_offer]);
            $prod_ids = array_keys($combo_product_as_offer);
            if (!empty($prod_ids)) {
                $cart_offer_insert_ar = [];
                $prod_rec = \DB::table('products')->whereIn('id', $prod_ids)->get();
                if (!empty(count($prod_rec->toArray()))) {
                    foreach ($prod_rec as $t) {
                        if (!in_array($t->id, $cart_product_ids)) {
                            $discount_type = $combo_product_as_offer[$t->id]['discount_type'];
                            $discount_value = $combo_product_as_offer[$t->id]['discount'];
                            $discount_amount = $discount_type == 'Flat' ? $discount_value : ($t->sale_price * $discount_value / 100);
                            $cart_offer_insert_ar[] = [
                                'product_id' => $t->id,
                                'name' => $t->name,
                                'sgst' => $t->sgst ?? 0,
                                'cgst' => $t->cgst ?? 0,
                                'igst' => $t->igst ?? 0,
                                'price' => $t->price,
                                'qty' => $combo_product_as_offer[$t->id]['qty'] * $combo_product_as_offer[$t->id]['multiple'],
                                'sale_price' => $t->sale_price,
                                'discount_type' => $discount_type,
                                'discount' => $discount_value,
                                'is_combo' => 'Yes',
                                'cart_session_id' => $row->cart_session_id,
                                'unit' => $t->unit,
                                'which_combo_rule_id' => $combo_product_as_offer[$t->id]['combo_rule_id'],
                            ];
                        } else {
                            $prev_qty = \DB::table('carts')->whereCartSessionId($row->cart_session_id)->whereUserId($user_id)->whereProductId($t->id)->first()->qty;
                            $new_qty = $combo_product_as_offer[$t->id]['qty'] * $combo_product_as_offer[$t->id]['multiple'];
                            \DB::table('carts')->whereCartSessionId($row->cart_session_id)->whereUserId($user_id)->whereProductId($t->id)->update([
                                'qty' => $prev_qty > $new_qty ? $prev_qty : $new_qty,
                                'discount' => $combo_product_as_offer[$t->id]['discount'],
                                'discount_type' => $combo_product_as_offer[$t->id]['discount_type'],
                                'discount_applies_on_qty' => $new_qty,
                                'is_combo' => 'Yes',

                            ]);

                        }
                    }
                    if (!empty($cart_offer_insert_ar)) {
                        \DB::table('carts')->insert($cart_offer_insert_ar);
                    }

                }

            }
        } else {
            \DB::table('carts')->where(['user_id' => $user_id, 'is_combo' => 'Yes', 'cart_session_id' => $row->cart_session_id])->delete();
        }
        $carts = \DB::table('carts')->where('cart_session_id', $row->cart_session_id)->get()->toArray();

        return response()->json(['data' => $carts], 201);
    }

    public function getComboProductsOffer($cart_session_id)
    {
        $offer_product_to_claim = [];
        $on_buy_qty = 0;
        $multiple = 1;
        $combos = \DB::table('combo_offers')->whereStatus('Active')->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now())->get();
        $cart_products = \DB::table('carts')->where('cart_session_id', $cart_session_id)->get(['product_id', 'qty'])->pluck('qty', 'product_id')->toArray();
        if (count($combos->toArray()) > 0) {
            foreach ($combos as $c) {
                Log::info('loopin');
                $today = date("Y-m-d H:i:s");
                $start = $c->start_date;
                $end = $c->end_date;
                $apply_rule = true;
                $should_add_product_as_offer = false;
                $customer_grps_applied = $c->customer_group_id ? array_column(json_decode($c->customer_group_id, true), 'id') : [];
                $customer_grps_applied = !empty($customer_grps_applied) && empty($customer_grps_applied[0]) ? [] : $customer_grps_applied;
                if (!empty($customer_grps_applied)) {
                    $customer_group_ids = $this->getCustomerGroups();
                    if (empty($customer_group_ids)) {
                        $apply_rule = false;
                    } else {
                        if (count(array_intersect($customer_grps_applied, $customer_group_ids)) > 0) {
                            $apply_rule = true;
                        } else {
                            $apply_rule = false;
                        }

                    }
                }

                if (!empty($start) && (strtotime($start) <= strtotime($today)) && $apply_rule) {

                    if (strtotime($end) >= strtotime($today)) {
                        $apply_rule = true;
                    } else {
                        $apply_rule = false;
                    }
                    if (!empty($c->buy_products) && $apply_rule) {
                        $buy_products = json_decode($c->buy_products, true);
                        $buy_product_ids = array_column($buy_products, 'product_id');

                        if (count(array_intersect($buy_product_ids, array_keys($cart_products))) > 0) {
                            foreach ($buy_products as $item) {
                                if (in_array($item['product_id'], array_keys($cart_products))) {
                                    Log::info('required qty { for }{id}', ['id' => $item['qty'], 'for' => $item['product_id']]);
                                    $prod_id = $item['product_id'];
                                    if (isset($cart_products[$prod_id])) {
                                        $requird_qty = $item['qty'];
                                        $cart_qty = $cart_products[$prod_id];
                                        Log::info('cart item qty {for}{id}', ['id' => $cart_products, 'for' => $prod_id]);
                                        if ($cart_qty >= $requird_qty && $cart_qty % $requird_qty == 0) {
                                            $on_buy_qty = $requird_qty;
                                            $multiple = floor($cart_qty / $requird_qty);
                                            $should_add_product_as_offer = true;
                                        } else {
                                            $should_add_product_as_offer = false;
                                            break;
                                        }
                                    }
                                }

                            }
                        }
                    }

                }
                if ($should_add_product_as_offer) {
                    Log::info('shoud ladd');
                    $get_products = !empty($c->get_products) ? json_decode($c->get_products, true) : null;
                    if ($get_products) {
                        foreach ($get_products as $g) {
                            if (!empty($offer_product_to_claim)) {
                                if (!in_array($g['product_id'], array_keys($offer_product_to_claim))) {
                                    $prev_qty = $offer_product_to_claim[$g['product_id']]['qty'];
                                    $offer_product_to_claim[$g['product_id']]['qty'] = $prev_qt + $g['qty'];
                                    $offer_product_to_claim[$g['product_id']]['multiple'] = $multiple;
                                    $offer_product_to_claim[$g['product_id']]['buy_qty'] = $on_buy_qty;
                                }
                            } else {
                                $offer_product_to_claim[$g['product_id']] = [
                                    'buy_qty' => $on_buy_qty, 'multiple' => $multiple,
                                    'product_id' => $g['product_id'],
                                    'combo_rule_id' => $c->id, 'rule_name' => $c->title,
                                    'qty' => $g['qty'],
                                    'discount_type' => $g['discount_type'],
                                    'discount' => $g['discount'],
                                ];
                            }
                        }
                    }
                }
            }
        }
        return $offer_product_to_claim;
    }
    public function getProductRules($cart_item)
    {
        $discount_rules = [];
        $product_id = $cart_item->product_id;
        $item_category_id = \DB::table('products')->whereId($product_id)->first()->category_id;
        $product_rules = \DB::table('product_discount_rules')->whereStatus('Active')->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now())->get();
        if (count($product_rules->toArray()) > 0) {
            foreach ($product_rules as $rule) {
                $today = date("Y-m-d H:i:s");
                $start = $rule->start_date;
                $end = $rule->end_date;
                $apply_rule = true;
                $customer_grps_applied = $rule->customer_group_id ? array_column(json_decode($rule->customer_group_id, true), 'id') : [];
                $customer_grps_applied = !empty($customer_grps_applied) && empty($customer_grps_applied[0]) ? [] : $customer_grps_applied;

                if (!empty($customer_grps_applied)) {
                    $customer_group_ids = $this->getCustomerGroups();
                    if (empty($customer_group_ids)) {
                        $apply_rule = false;
                    } else {
                        if (count(array_intersect($customer_grps_applied, $customer_group_ids)) > 0) {
                            $apply_rule = true;
                        } else {
                            $apply_rule = false;
                        }

                    }
                }

                if (!empty($start) && (strtotime($start) <= strtotime($today)) && $apply_rule) {

                    if (strtotime($end) >= strtotime($today)) {
                        $apply_rule = true;
                    } else {
                        $apply_rule = false;
                    }
                    $categories = json_decode($rule->category_id, true);
                    if ($rule->only_category_apply == 'Yes' && !in_array($item_category_id, $categories)) {
                        $apply_rule = false;
                    }
                    if ($apply_rule) {
                        $product_ids = $rule->product_id != null ? array_column(json_decode($rule->product_id, true), 'id') : null;
                        if ($product_ids && in_array($cart_item->product_id, $product_ids)) {
                            $item_qty = $cart_item->qty;

                            if (!empty($rule->quantity_rule)) {

                                $qty_rules_ar = json_decode($rule->quantity_rule, true);
                                foreach ($qty_rules_ar as $qr) {
                                    if ($qr['is_range'] == 'Yes') {
                                        $go = true;
                                        if (isset($qr['max_quantity']) && !empty($qr['max_quantity'])) {
                                            if ($qr['max_quantity'] < $item_qty) {
                                                continue;
                                            }

                                        }
                                        if (isset($qr['min_quantity']) && !empty($qr['min_quantity'])) {
                                            if ($qr['min_quantity'] > $item_qty) {
                                                continue;
                                            }

                                        }
                                        // $product_offer_detail_text=$item_qty.' Items have discount of '.($qr['discount_type']=='Flat'
                                        // ?'Rs.'.$qr['discount'].' each'
                                        // :$qr['discount'].'% each');
                                        $discount_rules[] = [
                                            'rule_name' => $rule->name, 'offer_text' => '',
                                            'discount_type' => $qr['discount_type'],
                                            'discount' => $qr['discount'], 'has_range' => 'Yes',
                                            'min_qty' => $qr['min_quantity'], 'max_qty' => $qr['max_quantity'],
                                        ];
                                    } else {
                                        $required_qty = isset($qr['min_quantity']) ? $qr['min_quantity'] : $qr['max_quantity'];
                                        $product_offer_detail_text = '';
                                        if ($required_qty <= $item_qty) {
                                            if ($required_qty < $item_qty) {
                                                $text_when_qty_more = $required_qty . ' Items have discount of ' . ($qr['discount_type'] == 'Flat'
                                                    ? 'Rs.' . $qr['discount'] . ' each'
                                                    : $qr['discount'] . '% each');
                                                if ($cart_item->discount_type != null) {
                                                    $text_when_qty_more .= '<br>remaining ' . $item_qty - $required_qty . ' items have discount of ';
                                                    $text_when_qty_more .= $cart_item->discount_type == 'Flat'
                                                    ? 'Rs.' . $cart_item->discount . ' each'
                                                    : $cart_item->discount . '% each';
                                                }
                                                $product_offer_detail_text = $text_when_qty_more;
                                            } else {
                                                $product_offer_detail_text = $required_qty . ' Items have discount of ' . ($qr['discount_type'] == 'Flat'
                                                    ? 'Rs.' . $qr['discount'] . ' each'
                                                    : $qr['discount'] . '% each');
                                            }

                                            $discount_rules[] = [
                                                'rule_name' => $rule->name,
                                                'offer_text' => $product_offer_detail_text,
                                                'discount_type' => $qr['discount_type'],
                                                'discount' => $qr['discount'],
                                                'has_range' => 'No',
                                                'exact_qty' => $required_qty,
                                            ];
                                        }

                                    }

                                }

                            }
                        }
                    }
                }

            }
        }
        Log::info('discount rile product {id}', ['id' => $discount_rules]);
        return $discount_rules;
    }
    public function getCustomerGroups()
    {
        $customer_grp_ids = [];
        $userid = 1;
        // $last_order = \DB::table('orders')->whereUserId('1')->latest()->first();
        // $last_order_date = null;
        // if (!is_null($last_order)) {
        //     $last_order_date = $last_order->created_at;
        // }

        $c_groups = \DB::table('customer_groups')->whereStatus('Active')->get();
        foreach ($c_groups as $cg) {
            $is_rule_applied = false;
            $purchase_amount_rule = !empty($cg->purchase_amount_rule) ? json_decode($cg->purchase_amount_rule, true)[0] : [];
            $order_count_rules = !empty($cg->order_count_rules) ? json_decode($cg->order_count_rules, true)[0] : [];
            $subscription_rule = !empty($cg->subscription_rule) ? json_decode($cg->subscription_rule, true)[0] : [];
            $joining_rule = !empty($cg->joining_rule) ? json_decode($cg->joining_rule, true)[0] : [];
            $abandoned_checkout_rule = !empty($cg->abandoned_checkout_rule) ? json_decode($cg->abandoned_checkout_rule, true)[0] : [];
            $joining_rule = !empty($cg->joining_rule) ? json_decode($cg->joining_rule, true)[0] : [];
            $incomplete_order_rule = !empty($cg->incomplete_order_rule) ? json_decode($cg->incomplete_order_rule, true)[0] : [];
            if (!empty($purchase_amount_rule)) {
                $since_days = isset($purchase_amount_rule['within_days']) ? $purchase_amount_rule['within_days'] : null;
                $order_amount = 0;
                if ($since_days) {
                    $order_amount = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->sum('gross_total');
                } else {
                    $order_amount = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->sum('gross_total');
                }
                $minimum = ($purchase_amount_rule['minimum_amount']) ? $purchase_amount_rule['minimum_amount'] : 0;
                if ($purchase_amount_rule['maximum_amount']) {
                    $is_rule_applied = $order_amount >= $minimum && $order_amount <= $purchase_amount_rule['maximum_amount'];
                } else {
                    $is_rule_applied = $order_amount >= $minimum;
                }

            }
            if (!empty($order_count_rules)) {

                $since_days = isset($order_count_rules['within_days']) ? $order_count_rules['within_days'] : null;

                $order_count = 0;
                if ($since_days) {
                    $order_count = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->count();
                } else {
                    $order_count = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->count();
                }
                $minimum = ($order_count_rules['minimum']) ? $order_count_rules['minimum'] : 0;
                if ($order_count_rules['maximum']) {
                    $is_rule_applied = $order_count >= $minimum && $order_amount <= $order_count_rules['maximum'];
                } else {
                    $is_rule_applied = $order_count >= $minimum;
                }

            }
            if (!empty($joining_rule)) {
                $since_days = $joining_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('users')->whereUserId($userid)->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if (!empty($abandoned_checkout_rule)) {
                $since_days = $abandoned_checkout_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('carts')->whereUserId($userid)->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if (!empty($incomplete_order_rule)) {
                $since_days = $incomplete_order_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('orders')->whereUserId($userid)->wherePaidStatus('Pending')->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if ($is_rule_applied) {
                $customer_grp_ids[] = $cg->id;
            }

        }
        return $customer_grp_ids;
    }

    public function getCartCountAmountAndDiscounts($cart_session_id)
    {
        $cart_amount_val = 0;
        $is_free_shipping = false;
        $total_coupon_discount = 0;

        $cart_amount_without_offer = 0;
        $cart_level_discount = 0;
        $individualItemOfferDiscount = 0;
        $carts = \DB::table('carts')->where('cart_session_id', $cart_session_id)->whereUserId(1)->get();

        foreach ($carts as $el) {
            $price = $el->salePrice != null && $el->salePrice > 0 ? $el->salePrice : $el->price;
            $cart_amount_without_offer += $price * $el->qty;
            $offerDiscount = 0.0;

            //**this discount is on overall cost of item so no need to multiply by qty on discount just totalcost-discount */
            if ($el->discount_rules != null) {
                foreach ($el->discount_rules as $el1) {
                    if ($el1->discount_type != null && $el1->discount != null) {
                        $offerDiscount += $el1->discount_type == 'Flat'
                        ? $el1->discount
                        : ($price * $el1->discount / 100);
                    }

                };

            }
            $individualItemOfferDiscount = $offerDiscount;
            $cart_amount_val += ($price * $el->qty) - $offerDiscount;
        }

        $applied_cart_rules = \DB::table('applied_cart_rule')->where('cart_session_id', $cart_session_id)->whereUserId(1)->whereStatus('Unused')->first();

        if (!is_null($applied_cart_rules)) {
            $cart_rules = json_decode($rule->cart_rule, true);
            foreach ($cart_rules as $pl) {
                $discount_amount = $pl['discount_type'] == 'Flat' ? $pl['discount'] : ($cart_amount_val * $pl['discount']) / 100;
                $total_coupon_discount += $discount_amount;
                if (!$is_free_shipping) {
                    $is_free_shipping = isset($pl['free_shipping']) && $pl['free_shipping'];
                }

            }
        }
        $applied_coupons = \DB::table('applied_coupons')->where('cart_session_id', $cart_session_id)->whereUserId(1)->whereStatus('Unused')->first();

        if (!is_null($applied_coupons)) {
            $coupons = json_decode($rule->coupons, true);
            foreach ($coupons as $pl) {
                $discount_amount = $pl['discount_type'] == 'Flat' ? $pl['discount'] : ($cart_amount_val * $pl['discount']) / 100;
                $total_coupon_discount += $discount_amount;
                if (!$is_free_shipping) {
                    $is_free_shipping = isset($pl['free_shipping']) && $pl['free_shipping'];
                }

            }
        }
        /**cart_amount_val includes in it the product itme level discount rules after aplied */
        return [
            'cart_amount' => $cart_amount_val - $cart_discount - $total_coupon_discount,
            'cart_amount_without_offer' => $cart_amount_without_offer,
            'cart_Count' => count($carts->toArray()),
            'cart_offer_discount' => cart_discount,
            'total_coupon_discount' => $total_coupon_discount,
            'individualItemOfferDiscount' => $individualItemOfferDiscount,
            'free_shipping' => $is_free_shipping,
        ];

    }

    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $r, $id)
    {
        Log::info("cart delete called {id}", ['id' => $id]);
        $carts = \DB::table('carts')->whereId($id)->delete();

        return response()->json(['data' => 'delete auccessfully'], 200);
    }
}
