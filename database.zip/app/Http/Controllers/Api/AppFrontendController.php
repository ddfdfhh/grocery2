<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use \Carbon\Carbon;

class AppFrontEndController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getContentSections()
    {
        $bulk_discounts = \DB::table('bulk_discounts')->whereStatus('Active')
            ->whereDate('start_date', '>=', Carbon::now())
            ->whereDate('end_date', '<=', Carbon::now())
            ->get();
        $category_dis = [];
        $prod_dis = [];
        $categories_with_offer = [];
        $products_with_offer = [];
        if (count($bulk_discounts->toArray()) > 0) {
            foreach ($bulk_discounts as $dis) {
                $categories = $dis->category_id ? json_decode($dis->category_id, true) : null;
                $products = $dis->product_id ? json_decode($dis->product_id, true) : null;
                if (!is_null($categories) && is_null($products)) {
                    foreach ($categories as $cat) {
                        $category_dis[$cat['id']] = [
                            'rule_name' => $dis->name,
                            'discount_type' => $dis->discount_type,
                            'discount' => $dis->discount,

                        ];
                    }
                } else {
                    if (!is_null($products)) {
                        foreach ($products as $prod) {
                            $prod_disc[$prod['id']] = [
                                'rule_name' => $dis->name,
                                'discount_type' => $dis->discount_type,
                                'discount' => $dis->discount,

                            ];
                        }
                    }
                }

            }
            $categories_with_offer = array_keys($category_dis);
            $products_with_offer = array_keys($prod_disc);
        }

        $sections = \App\Models\ContentSection::with(['products', 'categories.children', 'banner.banner_images'])
            ->whereVisible('Yes')->orderBy('section_number', 'Asc')->get();
        // dd($sections->toArray());
        foreach ($sections as $t) {
            if (!empty($t->categories)) {
                foreach ($t->categories as $r) {
                    if (!empty($categories_with_offer)) {
                        if (in_array($r->id, $categories_with_offer)) {
                            if (isset($category_dis[$r->id])) {
                                $r->discount_type = $category_dis[$r->id]['discount_type'];
                                $r->discount = $category_dis[$r->id]['discount'];
                            }
                        }
                    }

                    $r->thumbnail = [];
                    if ($r->image) {
                        $r->thumbnail = getThumbnailsFromImage($r->image);
                    }

                    $r->children_count = count($r->children);
                    unset($r->children);
                    unset($r->deleted_at);
                    unset($r->pivot);
                }
            }
            if (!empty($t->products)) {
                foreach ($t->products as $r) {
                    if (!empty($products_with_offer)) {
                        if (in_array($r->id, $products_with_offer)) {
                            if (isset($prod_dis[$r->id])) {
                                $r->discount_type = $prod_dis[$r->id]['discount_type'];
                                $r->discount = $prod_dis[$r->id]['discount'];
                            }
                        }
                    }

                }
            }
            if ($t->banner) {
                $t->banner_images = $t->banner->banner_images;
                unset($t->banner);
            } else {
                $t->banner_images = null;
            }

        }

        return response()->json(['data' => $sections], 200);
    }
    public function getSingleContentSection($id)
    {
        $bulk_discounts = \DB::table('bulk_discounts')->whereStatus('Active')
            ->whereDate('start_date', '>=', Carbon::now())
            ->whereDate('end_date', '<=', Carbon::now())
            ->get();
        $category_dis = [];
        $prod_dis = [];
        $categories_with_offer = [];
        $products_with_offer = [];
        if (count($bulk_discounts->toArray()) > 0) {
            foreach ($bulk_discounts as $dis) {
                $categories = $dis->category_id ? json_decode($dis->category_id, true) : null;
                $products = $dis->product_id ? json_decode($dis->product_id, true) : null;
                if (!is_null($categories) && is_null($products)) {
                    foreach ($categories as $cat) {
                        $category_dis[$cat['id']] = [
                            'rule_name' => $dis->name,
                            'discount_type' => $dis->discount_type,
                            'discount' => $dis->discount,

                        ];
                    }
                } else {
                    if (!is_null($products)) {
                        foreach ($products as $prod) {
                            $prod_disc[$prod['id']] = [
                                'rule_name' => $dis->name,
                                'discount_type' => $dis->discount_type,
                                'discount' => $dis->discount,

                            ];
                        }
                    }
                }

            }
            $categories_with_offer = array_keys($category_dis);
            $products_with_offer = array_keys($prod_disc);
        }

        $t = \App\Models\ContentSection::with(['products', 'categories.children', 'banner.banner_images'])
            ->whereVisible('Yes')->whereId($id)->first();

        if (!empty($t->categories)) {
            foreach ($t->categories as $r) {
                if (!empty($categories_with_offer)) {
                    if (in_array($r->id, $categories_with_offer)) {
                        if (isset($category_dis[$r->id])) {
                            $r->discount_type = $category_dis[$r->id]['discount_type'];
                            $r->discount = $category_dis[$r->id]['discount'];
                        }
                    }
                }

                $r->thumbnail = [];
                if ($r->image) {
                    $r->thumbnail = getThumbnailsFromImage($r->image);
                }

                $r->children_count = count($r->children);
                unset($r->children);
                unset($r->deleted_at);
                unset($r->pivot);
            }
        }
        if (!empty($t->products)) {
            foreach ($t->products as $r) {
                if (!empty($products_with_offer)) {
                    if (in_array($r->id, $products_with_offer)) {
                        if (isset($prod_dis[$r->id])) {
                            $r->discount_type = $prod_dis[$r->id]['discount_type'];
                            $r->discount = $prod_dis[$r->id]['discount'];
                        }
                    }
                }

            }
        }
        if ($t->banner) {
            $t->banner_images = $t->banner->banner_images;
            unset($t->banner);
        } else {
            $t->banner_images = null;
        }

        return response()->json(['data' => $t], 200);
    }
    public function getDealsSections()
    {
        $sections = \DB::table('bulk_discounts')
            ->select('name', 'details', 'category_id AS category', 'product_id as product',
                'start_date', 'end_date', 'discount_type', 'discount')
            ->whereStatus('Active')->orderBy('order_number', 'ASC')->get();
        foreach ($sections as $r) {
            $r->category = $r->category ? json_decode($r->category, true) : [];
            $r->product = $r->product ? json_decode($r->product, true) : [];

        };
        return response()->json(['data' => $sections], 200);
    }
    public function getBanners()
    {
        $sections = \App\Models\Banner::with('banner_images')->get();
        return response()->json(['data' => $sections], 200);
    }
}
