<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $r)
    {
        //
    }

    public function show($id)
    {
        Log::info('fetcingr  here isingele vorder {id}', ['id' => $id]);
        $order = \App\Models\Order::with(['user' => function ($q) {
            $q->select('id', 'name', 'phone', 'lat', 'lang', 'address', 'pincode');
        }, 'driver' => function ($q) {
            $q->select('id', 'name', 'phone');
        }, 'items'])->whereId($id)->first();
        Log::info('order {id}', ['id' => $order]);
        return response()->json(['data' => $order], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    public function store(Request $r)
    {
        $setting = \DB::table('settings')->first();
        $shipping_charge = $setting != null ? $setting->delivery_charge : 0;
        $email = $r->email;
        $phone = $r->phone;

        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $user_id = $user->id;
        $cart_session_id = $r->cart_session_id;

        $ar = $this->getCartCountAmountAndDiscounts($cart_session_id, $user_id);
        $shipping_cost = $ar['free_shipping'] ? 0 : $shipping_charge;
        $carts = \DB::table('carts')->whereUserId($user_id)->where('cart_session_id', $cart_session_id)->get()->toArray();
        $order_items_ar = [];
        $total_items = 0;
        $total_discount = 0;
        $net_payable = 0;
        $total_amount_after_discount = 0;
        $total_amount = 0;
        $total_tax = 0;
        foreach ($carts as $t) {

            unset($t->id);
            unset($t->category_id);
            unset($t->created_at);
            unset($t->updated_at);
            unset($t->discount_applies_on_qty);
            
            $total_items += 1;

            $order_items_ar[] = (array) $t;
            $total_discount += $t->total_discount;
            $total_amount_after_discount += $t->net_cart_amount;
            $total_amount += $t->price * $t->qty;
            $total_tax += $t->total_tax;

        }
        //   dd($order_items_ar);
        $orderid = null;
        if (!empty($order_items_ar)) {
            \DB::table('order_items')->whereCartSessionId($cart_session_id)->whereUserId($user_id)->delete();
            \DB::table('orders')->whereCartSessionId($cart_session_id)->whereUserId($user_id)->delete();
            unset($order_items_ar['max_qty_allowed']);
           
            \DB::table('order_items')->insert($order_items_ar);
            $net_payable = $total_amount_after_discount + $total_tax + $shipping_cost;
            $razor_orderId = null;
            if ($r->payment_method == 'Online') {
                $report = new PaymentController;
                $razor_orderId = $report->createOrderId($net_payable, $user_id);
            }
            $order_id = 'T' . date('ymdhi') . mt_rand(1000, 9999) . $user_id;
            $status_updates=[
                [
                    'name'=>'Pending',
                    'message'=>'','date'=>date('Y-m-d H:i:s')
                ]
            ];
            $order_ar = [
                'total_amount' => $total_amount,
                'total_amount_after_discount' => $total_amount_after_discount,
                'cart_session_id' => $cart_session_id,
                'net_payable' => $net_payable,
                'shipping_cost' => $shipping_cost,
                'total_tax' => $total_tax,
                'user_id' => $user_id,
                'slot_time' => $r->slot_time,
                'no_of_items'=>$total_items,
                'slot_date' => date("Y-m-d", strtotime($r->slot_date)),
                'uuid' => $order_id,
                'payment_method' => $r->payment_method,
                'razorpay_order_id' => $razor_orderId,
                'order_status_updates'=>json_encode($status_updates)
            ];
            $orderid = \DB::table('orders')->insertGetId($order_ar);
            \DB::table('order_items')->whereCartSessionId($cart_session_id)->update(['order_id' => $orderid]);
        }

        if ($r->payment_method != 'Online') {

            \DB::table('carts')->whereUserId($user_id)->whereCartSessionId($cart_session_id)->delete();
        }
        return response()->json(['data' => $r->payment_method == 'Online' ? ['orderId' => $razor_orderId, 'user_id' => $user_id, 'table_order_id' => $orderid] : 'Placed order successfully'], 201);
    }
    // public function store(Request $request)
    // {
    //     $ids = explode('_', $request->cartIds);
    //     $coupon_id = $r->coupon_id;
    //     $userid = 1;
    //     Log::info("d {id}", ['id' => $ids]);
    //     $cartids = [];
    //     if (!empty($ids)) {
    //         $cartids = explode('_', $ids);

    //     }
    //     $carts = \DB::table('carts')->whereIn('id', $cartids)->get();
    //     $insert_ar = [];
    //     $total_discount = 0;
    //     $total_tax = 0;
    //     $total_shipping = 0;
    //     $gross_total = 0;
    //     $net_amount = 0;

    //     $order_items_ar = [];
    //     foreach ($carts as $t) {
    //         $order_items_ar[] = $t->toArray();
    //         $sale_price = $t->sale_price;
    //         $qty = $t->qty;
    //         $gross_total += $sale_price * $qty;
    //         $discount_type = $t->discount_type;
    //         $discount_val = $t->discount;

    //         $discount_amount = 0;
    //         if ($discount && $discount_type) {
    //             $discount_amount = $discount_type == 'Percent' ? number_format(($sale_price * $discount_val) / 100, 2) : $discount_val;
    //             $total_discount += $discount_amount;
    //         }
    //         $discounted_price = $sale_price - $discount_amount;
    //         $tax = number_format(($discounted_price * ($sgst + $cgst + $igst)) / 100, 2);
    //         $total_tax += $tax;

    //     }
    //     if (!empty($order_items_ar)) {
    //         \DB::table('order_items')->whereCartSessionId($order_items_ar[0]['cart_session_id'])->delete();
    //         \DB::table('order_items')->insert($order_items_ar);
    //         $net_amount = $gross_total - $total_discount + $total_tax + $total_shipping;
    //         $order_uid = $user_id . uniquid();
    //         \DB::table('orders')->insert(
    //             [
    //                 'uuid' => $order_uid,
    //                 'gross_total' => $gross_total,
    //                 'total_discount' => $total_discount,
    //                 'total_tax' => $total_tax,
    //                 'shipping_cost' => $total_shipping,
    //                 'net_payable' => $net_payable,
    //                 'user_id' => $userid,
    //             ]
    //         );
    //         return response()->json(['message' => 'Succesfully placed'], 200);
    //     } else {
    //         return response()->json(['message' => 'Faield to place order'], 400);
    //     }

    // }
    public function applyAndReturnCartlevelDiscounts(Request $r)
    {
        $cart_session_id = $r->cart_session_id;
        $email = $r->email;
        $phone = $r->phone;

        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $user_id = $user->id;
        Log::info('cart sessio id{id}', ['id' => $cart_session_id]);

        $discounts = [];
        if ($cart_session_id) {
            $discounts = $this->whole_cart_level_discount_rule($cart_session_id);
            Log::info('cart lvevle discounts {id}', ['id' => $discounts]);
            $applied_cart_rules_exist = \DB::table('applied_cart_rules')
                ->whereUserId($user_id)
                ->where('cart_session_id', $cart_session_id)->exists();
            if ($applied_cart_rules_exist) {
                \DB::table('applied_cart_rules')->whereUserId($user_id)->where('cart_session_id', $cart_session_id)->delete();
            }
            \DB::table('applied_cart_rules')->insert([
                'user_id' => $user_id,
                'cart_session_id' => $cart_session_id,
                'discounts' => json_encode($discounts),
                'status' => 'Unused',
            ]);
        }
        return response()->json(['data' => $discounts], 200);
    }

    public function whole_cart_level_discount_rule($cart_session_id)
    {
        $info = $this->getCartCountAmountAndDiscounts($cart_session_id);
        $cart_amount = $info['cart_amount_without_offer'] - $info['individualItemOfferDiscount'];
        $discounts = [];
        $cart_rules = \DB::table('cart_rules')->whereStatus('Active')->get();
        if (count($cart_rules->toArray()) > 0) {
            foreach ($cart_rules as $c) {
                $today = date("Y-m-d H:i:s");
                $start = $c->start_date;
                $end = $c->end_date;
                $apply_rule = true;
                $should_add_product_as_offer = false;
                $customer_grps_applied = $c->customer_group_id ? array_column(json_decode($c->customer_group_id, true), 'id') : [];

                $customer_grps_applied = !empty($customer_grps_applied) && empty($customer_grps_applied[0]) ? [] : $customer_grps_applied;

                if (!empty($customer_grps_applied)) {
                    $customer_group_ids = $this->getCustomerGroups();
                    if (empty($customer_group_ids)) {
                        $apply_rule = false;
                    } else {
                        if (count(array_intersect($customer_grps_applied, $customer_group_ids)) > 0) {
                            $apply_rule = true;
                        } else {
                            $apply_rule = false;
                        }

                    }
                }

                if (!empty($start) && (strtotime($start) <= strtotime($today)) && $apply_rule) {

                    if (strtotime($end) >= strtotime($today)) {
                        $apply_rule = true;
                    } else {
                        $apply_rule = false;
                    }
                    if ($apply_rule) {
                        if ($c->based_on == 'Amount') {
                            $min = $c->from_value ? $c->from_value : 0;
                            $max = $c->to_value;
                            if ($max) {
                                if ($cart_amount >= $min && $cart_amount <= $max) {
                                    $discounts[] = ['discount' => $c->discount, 'discount_type' => $c->discount_type
                                        , 'free_shipping' => $c->free_shipping, 'cart_rule_id' => $c->id, 'rule_name' => $c->title];
                                }
                            }
                        } elseif ($c->based_on == 'Quantity') {
                            $min = $c->from_value ? $c->from_value : 0;
                            $max = $c->to_value;
                            if ($max) {
                                if ($cart_items_count >= $min && $cart_items_count <= $max) {
                                    $discounts[] = [
                                        'discount' => $c->discount, 'cart_rule_id' => $c->id,
                                        'discount_type' => $c->discount_type,
                                        'free_shipping' => $c->free_shipping, 'rule_name' => $c->title,
                                    ];
                                }
                            }
                        }
                    }

                }

            }
        }
        return $discounts;
    }
    public function getCartCountAmountAndDiscounts($cart_session_id, $user_id)
    {
        $cart_amount_val = 0;
        $is_free_shipping = false;
        $total_coupon_discount = 0;
        $cart_amount_without_offer = 0;
        $cart_level_discount = 0;
        $individualItemOfferDiscount = 0;
        $carts = \DB::table('carts')->where('cart_session_id', $cart_session_id)->whereUserId($user_id)->get();
        $total_tax = 0;
        foreach ($carts as $el) {
            $price = $el->price;
            $sale_price = $el->sale_price;
            $cart_amount_without_offer += $price * $el->qty;
            $offerDiscount = 0.0;
            $deal_discount = 0;
            //**this discount is on overall cost of item so no need to multiply by qty on discount just totalcost-discount */
            if ($el->discount_rules != null) {
                $el->discount_rules = json_decode($el->discount_rules);
                foreach ($el->discount_rules as $el1) {
                    if ($el1->discount_type != null && $el1->discount != null) {
                        $offerDiscount += $el1->discount_type == 'Flat'
                        ? $el1->discount
                        : ($price * $el1->discount / 100);
                    }

                };

            } else {
                if ($el->discount_type != null && $el->discount != null) {
                    $dis = $el->discount_type == 'Flat'
                    ? $el->discount
                    : ($price * $el->discount / 100);
                    $deal_discount += $dis;

                }
            }
            $individualItemOfferDiscount += $offerDiscount + $deal_discount;
            if ($deal_discount > 0 || $offerDiscount > 0) {
                $price_after_offer_discount = (($price - $deal_discount) * $el->qty) - $offerDiscount;
            } else {
                $price_after_offer_discount = $sale_price * $el->qty;
            }

            $cart_amount_val += $price_after_offer_discount;
            /**tax is aplied on after applying individual item discount */
            $tax = number_format(($price_after_offer_discount * ($el->sgst + $el->cgst + $el->igst)) / 100, 2);
            $total_tax += $tax;

        }

        $applied_cart_rules = \DB::table('applied_cart_rules')->where('cart_session_id', $cart_session_id)->whereUserId($user_id)->whereStatus('Unused')->first();

        if (!is_null($applied_cart_rules)) {
            $cart_rules = json_decode($applied_cart_rules->discounts, true);
            foreach ($cart_rules as $pl) {
                $discount_amount = $pl['discount_type'] == 'Flat' ? $pl['discount'] : ($cart_amount_val * $pl['discount']) / 100;
                $cart_level_discount += $discount_amount;
                if (!$is_free_shipping) {
                    $is_free_shipping = isset($pl['free_shipping']) && $pl['free_shipping'];
                }

            }
        }
        $applied_coupon = \DB::table('applied_coupons')->where('cart_session_id', $cart_session_id)->whereUserId($user_id)->first();

        if (!is_null($applied_coupon)) {
            $discount_amount = $applied_coupon->discount_type == 'Flat' ? $applied_coupon->discount :
            ($cart_amount_val * $applied_coupon->discount) / 100;
            $total_coupon_discount += $discount_amount;
            if (!$is_free_shipping) {
                $is_free_shipping = isset($applied_coupon->free_shipping) && $applied_coupon->free_shipping;
            }

        }
        /**cart_amount_val includes in it the product itme level discount rules and bulk deal discount after aplied */
        return [
            'cart_amount' => $cart_amount_val - $cart_level_discount - $total_coupon_discount, /***this amount after all deductions to show in live cart  */
            'cart_amount_without_offer' => $cart_amount_without_offer, /**this amount only cout of sale price with qty */
            'cart_Count' => count($carts->toArray()),
            'cart_offer_discount' => $cart_level_discount,
            'total_coupon_discount' => $total_coupon_discount,
            'individualItemOfferDiscount' => $individualItemOfferDiscount,
            'free_shipping' => $is_free_shipping,
            'total_tax' => $total_tax,
        ];

    }
    public function getCoupons()
    {
        $coupons = \DB::table('coupons')->whereStatus('Active')->get();
        $coupon_ar = [];
        if (count($coupons->toArray()) > 0) {

            foreach ($coupons as $c) {
                $add_coupon = false;
                $today = date("Y-m-d H:i:s");
                $start = $c->start_date;
                $end = $c->end_date;
                if (!empty($start) && (strtotime($start) <= strtotime($today))) {
                    $add_coupon = true;
                    if (!empty($end)) {
                        if (strtotime($end) >= strtotime($today)) {
                            $add_coupon = true;
                        } else {
                            $add_coupon = false;

                        }

                    }

                }if ($add_coupon) {
                    $coupon_ar[] = $c;
                }
            }

        }
        return response()->json(['data' => $coupon_ar], 200);
    }
    public function applyCoupon(Request $r)
    {
        $cart_session_id = $r->cart_session_id;
        $coupon_id = $r->coupon_id;
        $email = $r->email;
        $phone = $r->phone;

        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $user_id = $user->id;

        $coupon_discounts = [];
        $coupon_row = \DB::table('coupons')->whereId($coupon_id)->whereStatus('Active')->first();
        $can_coupon_be_used = false;
        $error_message = '';
        if (!is_null($coupon_row)) {
            $today = date("Y-m-d H:i:s");
            $start = $coupon_row->start_date;
            $end = $coupon_row->end_date;
            $apply_coupon = true;
            $customer_grps_applied = $coupon_row->customer_group_id ? array_column(json_decode($coupon_row->customer_group_id, true), 'id') : [];

            $customer_grps_applied = !empty($customer_grps_applied) && empty($customer_grps_applied[0]) ? [] : $customer_grps_applied;

            if (!empty($customer_grps_applied)) {
                $customer_group_ids = $this->getCustomerGroups();
                if (empty($customer_group_ids)) {
                    $apply_coupon = false;
                } else {
                    if (count(array_intersect($customer_grps_applied, $customer_group_ids)) > 0) {
                        $apply_coupon = true;
                    } else {
                        $apply_coupon = false;
                        $error_message = 'You are not eligible for the coupon';

                    }

                }
            }
            if ($apply_coupon) {

                if (!empty($start) && (strtotime($start) <= strtotime($today))) {
                    $can_coupon_be_used = true;
                    if (!empty($end)) {
                        if (strtotime($end) >= strtotime($today)) {
                            $can_coupon_be_used = true;
                        } else {
                            $can_coupon_be_used = false;
                            $error_message = 'You are not eligible for the coupon';
                        }

                    }
                    if ($can_coupon_be_used) {
                        /***check usage limit */
                        $can_coupon_be_used = false;
                        if ($coupon_row->total_used_till_now < $coupon_row->customer_usage_limit) {
                            $can_coupon_be_used = true;
                            $customer_usage = \DB::table('coupon_usage_by_customers')->whereUserId($user_id)->whereCouponId($coupon_id)->first();
                            if (!is_null($customer_usage)) {
                                if ($customer_usage < $coupon_row->customer_usage_limit) {
                                    $can_coupon_be_used = true;
                                } else {
                                    $can_coupon_be_used = false;
                                    $error = "Coupon maximum usage limit reached for you";
                                }
                            }
                        } else {
                            $error = "Coupon maximum usage limit reached";
                        }

                    }
                } else {
                    $error_message = 'Coupon is expired';
                }

            }
            if ($can_coupon_be_used) {
                $coupon_applied_exist = \DB::table('applied_coupons')
                    ->whereUserId($user_id)
                    ->where('cart_session_id', $cart_session_id)->whereCouponId($coupon_id)->exists();
                if ($coupon_applied_exist) {
                    \DB::table('applied_coupons')
                        ->whereUserId($user_id)
                        ->where('cart_session_id', $cart_session_id)->delete();
                }
                \DB::table('applied_coupons')->insert([
                    'cart_session_id' => $cart_session_id,
                    'user_id' => $user_id,
                    'coupon_id' => $coupon_id,
                    'discount_type' => $coupon_row->discount_type,
                    'discount' => $coupon_row->discount,
                    'free_shipping' => $coupon_row->free_shipping ? 'Yes' : 'No',

                ]);
                $categories = $coupon_row->category_id != null ? array_column(json_decode($coupon_row->category_id, true), 'id') : [];
                $products = $coupon_row->product_id != null ? array_column(json_decode($coupon_row->product_id, true), 'id') : [];
                $cart_items = \DB::table('cart')
                    ->whereUserId($user_id)
                    ->where('cart_session_id', $cart_session_id)->get();
                $cart_product_ids = array_column($cart_items->toArray(), 'product_id');
                $update_arr = [];
                $insert_arr = [];

                if ($coupon_row->give_as_gift == 'Yes') { /**Agar free gift hoga to automatic append karna padge agar cart mein add nahi hai to otherwise update discount  */

                    foreach ($products as $p_id) {
                        $t = $cart_item_row = getRowFromCartItems($cart_items, $p_id);
                        if (in_array($p_id, $cart_product_ids)) {
                            $update_arr[] = ['id' => $t->id, 'discount_type' => 'Percent', 'discount' => 100, 'cart_session_id' => $cart_session_id,
                                'discount_applies_on_qty' => $coupon_row->product_qty_rule_applied,
                            ];
                        } else {

                            $insert_arr[] = [
                                'product_id' => $t->product_id,
                                'name' => $t->name,
                                'sgst' => $t->sgst ?? 0,
                                'cgst' => $t->cgst ?? 0,
                                'igst' => $t->igst ?? 0,
                                'price' => $t->price,
                                'qty' => $coupon_row->product_qty_rule_applied,
                                'sale_price' => $t->sale_price,
                                'discount_type' => 'Percent',
                                'discount' => 100,
                                'cart_session_id' => $t->cart_session_id,
                                'unit' => $t->unit,
                                'discount_applies_on_qty' => $coupon_row->product_qty_rule_applied,
                            ];
                        }
                    }
                } else { /***If not free gift then update only not automatic apend in cart */
                    if ($coupon_row->include_or_exclude == 'Include') {
                        foreach ($products as $p_id) {
                            $t = $cart_item_row = getRowFromCartItems($cart_items, $p_id);
                            if (in_array($p_id, $cart_product_ids)) {
                                $update_arr[] = ['id' => $t->id, 'discount_type' => $coupon_row->discount_type,
                                    'discount' => $coupon_row->discount,
                                    'cart_session_id' => $cart_session_id,
                                    'discount_applies_on_qty' => $coupon_row->product_qty_rule_applied,
                                ];
                            }

                        }
                    } /***include end */
                    else {
                        $cart_amount = getCartAmountAfterCurrentDiscountAplied($cart_items);

                    }
                }

                $coupon_discounts = [
                    'name' => $coupon_row->coupon_code,
                    'discount_type' => $coupon_row->discount_type,
                    'discount' => $coupon_row->discount,
                    'free_shipping' => $coupon_row->free_shipping ? 'Yes' : 'No',
                ];
            }
        }
        return response()->json(['data' => $coupon_discounts], 200);
    }
    public function getCustomerGroups()
    {
        $customer_grp_ids = [];
        $userid = 1;
        // $last_order = \DB::table('orders')->whereUserId('1')->latest()->first();
        // $last_order_date = null;
        // if (!is_null($last_order)) {
        //     $last_order_date = $last_order->created_at;
        // }

        $c_groups = \DB::table('customer_groups')->whereStatus('Active')->get();
        foreach ($c_groups as $cg) {
            $is_rule_applied = false;
            $purchase_amount_rule = !empty($cg->purchase_amount_rule) ? json_decode($cg->purchase_amount_rule, true)[0] : [];
            $order_count_rules = !empty($cg->order_count_rules) ? json_decode($cg->order_count_rules, true)[0] : [];
            $subscription_rule = !empty($cg->subscription_rule) ? json_decode($cg->subscription_rule, true)[0] : [];
            $joining_rule = !empty($cg->joining_rule) ? json_decode($cg->joining_rule, true)[0] : [];
            $abandoned_checkout_rule = !empty($cg->abandoned_checkout_rule) ? json_decode($cg->abandoned_checkout_rule, true)[0] : [];
            $joining_rule = !empty($cg->joining_rule) ? json_decode($cg->joining_rule, true)[0] : [];
            $incomplete_order_rule = !empty($cg->incomplete_order_rule) ? json_decode($cg->incomplete_order_rule, true)[0] : [];
            if (!empty($purchase_amount_rule)) {
                $since_days = isset($purchase_amount_rule['within_days']) ? $purchase_amount_rule['within_days'] : null;
                $order_amount = 0;
                if ($since_days) {
                    $order_amount = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->sum('gross_total');
                } else {
                    $order_amount = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->sum('gross_total');
                }
                $minimum = ($purchase_amount_rule['minimum_amount']) ? $purchase_amount_rule['minimum_amount'] : 0;
                if ($purchase_amount_rule['maximum_amount']) {
                    $is_rule_applied = $order_amount >= $minimum && $order_amount <= $purchase_amount_rule['maximum_amount'];
                } else {
                    $is_rule_applied = $order_amount >= $minimum;
                }

            }
            if (!empty($order_count_rules)) {

                $since_days = isset($order_count_rules['within_days']) ? $order_count_rules['within_days'] : null;

                $order_count = 0;
                if ($since_days) {
                    $order_count = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->count();
                } else {
                    $order_count = \DB::table('orders')->whereUserId($userid)->wherePaidStatus('Paid')
                        ->count();
                }
                $minimum = ($order_count_rules['minimum']) ? $order_count_rules['minimum'] : 0;
                if ($order_count_rules['maximum']) {
                    $is_rule_applied = $order_count >= $minimum && $order_amount <= $order_count_rules['maximum'];
                } else {
                    $is_rule_applied = $order_count >= $minimum;
                }

            }
            if (!empty($joining_rule)) {
                $since_days = $joining_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('users')->whereUserId($userid)->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if (!empty($abandoned_checkout_rule)) {
                $since_days = $abandoned_checkout_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('carts')->whereUserId($userid)->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if (!empty($incomplete_order_rule)) {
                $since_days = $incomplete_order_rule['within_days'];

                if ($since_days) {
                    if (\DB::table('orders')->whereUserId($userid)->wherePaidStatus('Pending')->whereDate('created_at', '>=', Carbon::now()->subDays($since_days))
                        ->exist()) {
                        $is_rule_applied = true;
                    }
                }

            }
            if ($is_rule_applied) {
                $customer_grp_ids[] = $cg->id;
            }

        }
        return $customer_grp_ids;
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function update_order_status()
    {
        $column = $r->column;
        $status = $r->status;
        $id = $r->order_id;
        \DB::table('orders')->whereId($id)->update([$column => $status]);
    }
    public function order_history(Request $r)
    {
        $email = $r->email;
        $phone = $r->phone;
        $status = null;
        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $orders = [];
        if (!is_null($user)) {
            $orders = \App\Models\Order::whereUserId($user->id)
                ->when(!empty($status), function ($query) use ($status) {
                    return $query->where('delivery_status', $status);
                })
                ->latest()->get()->toArray();

        }
        Log::info('fetcingr order history {id}', ['id' => $r->all()]);
        return response()->json(['data' => $orders], 200);

    }
    public function order_cancel(Request $r)
    {
        $email = $r->email;
        $phone = $r->phone;
        $id = $r->id;
        $user = \App\Models\User::where([
            'email' => $email,
            'phone' => $phone,

        ])->first();
        $orders = \App\Models\Order::whereId($id)->whereUserId($user->id)->update(['delivery_status' => 'Cancelled', 'cancelled_by' => 'Customer',
            'status_update_date' => date('Y-m-d H:i:s')]);
        //Log::info('cacnell ordered {id}', ['id' => $r->all()]);
        return response()->json(['data' => 'order Canceled '], 200);

    }
}
