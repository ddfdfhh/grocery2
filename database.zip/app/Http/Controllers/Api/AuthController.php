<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class AuthController extends Controller
{

    public function __construct()
    {
        // $this->middleware('auth:api', ['except' => ['login','register']]);
    }

    public function login(Request $r)
    {
        
        $r->validate([
            'email' => 'sometimes|string|email',
            'phone' => 'sometimes|numeric|digits:between:10,12',

        ]);
        $email = $r->has('email') ? $r->email : null;
        $phone = $r->has('phone') ? $r->phone : null;
        $user = \App\Models\User::when(!is_null($email), function ($q) use ($email) {
            return $q->whereEmail($email);
        })->when(!is_null($phone), function ($q) use ($phone) {
            return $q->wherePhoneNumber($phone);
        })->first();
        if (!is_null($user)) {
            $otp = rand(100000, 999999);
            if (\DB::table('user_otps')->where(['email' => $email, 'phone' => $phone])->exists()) {
                \DB::table('user_otps')->where(['email' => $email, 'phone' => $phone])->delete();
            }
            \DB::table('user_otps')->insert(['email' => $email, 'phone' => $phone, 'otp' => $otp, 'created_at' => date("Y-m-d H:i:s")]);
            try {
                $resp = $this->mail($email, 'OTP Verification', "Your Opt is -" . $otp);
            } catch (\Exception $ex) {
    
            }
            return response()->json(['data' => [
                'message' => 'User valid',

            ]], 200);
        } else {
            return response()->json(['data' => [
                'message' => 'User not found',

            ]], 404);
        }

    }

    public function register(Request $request)
    {
        Log::info("storing data {id}", ['id', $request->all()]);
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',

            'phone' => 'required|unique:users',

        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => mt_rand(1000000, 9999999),

        ]);
        $email = $request->email;
        $phone = $request->phone;
        $user->assignRole('Customer');
        $token = Auth::guard('api')->login($user);
        $user->token = $token;
        $user->save();
        $otp = rand(100000, 999999);
        if (\DB::table('user_otps')->where(['email' => $email, 'phone' => $phone])->exists()) {
            \DB::table('user_otps')->where(['email' => $email, 'phone' => $phone])->delete();
        }
        \DB::table('user_otps')->insert(['email' => $email, 'phone' => $phone, 'otp' => $otp, 'created_at' => date("Y-m-d H:i:s")]);
        try {
            $resp = $this->mail($email, 'OTP Verification', "Your Opt is -" . $otp);
        } catch (\Exception $ex) {

        }
        return response()->json(['data' => [
            'status' => 'success',
            'message' => 'User created successfully',
            'user' => $user,
            'token' => $token,

        ]], 200);
    }
    public function updateProfile(Request $request)
    {

        $user = User::where([
            'email' => $request->old_email,
            'phone' => $request->old_phone,

        ])->first();
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'nullable|min:6',
            'phone' => 'required|unique:users,phone,' . $user->id,
            'old_email' => 'required|string|email',
            'old_phone' => 'required',
            'address' => 'nullable',
        ]);

        Log::info("update use data {id}", ['id', $request->all()]);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->address = $request->address;
        $user->save();
        return response()->json(['data' => [
            'user' => $user,
            // 'user' => $user,
            // 'token' => $token,

        ]], 200);
    }
    public function logout()
    {
        Auth::guard('api')->logout();
        return response()->json([
            'status' => 'success',
            'message' => 'Successfully logged out',
        ]);
    }

    public function refresh()
    {
        return response()->json([
            'status' => 'success',
            'user' => Auth::user(),
            'authorisation' => [
                'token' => Auth::refresh(),
                'type' => 'bearer',
            ],
        ]);
    }
    public function update_address(Request $r)
    {
        // Log::info("shipping u {id}",['id'=>json_encode($r->all())]);
        $address = $r->address;
        $email = $r->email;
        $phone = $r->phone;

        \App\Models\User::where(['email' => $email, 'phone' => $phone])->update([
            'address' => $address, 'pincode' => $r->pin,

        ]);
        return response()->json(['message' => 'Updated Succefully'], 200);
    }
    public function verify_otp(Request $r)
    {
        Log::info("otp veri u {id}", ['id' => json_encode($r->all())]);
        $otp = $r->otp;
        $email = $r->has('email') && !empty($r->email) ? $r->email : null;
        $phone = $r->has('phone') && !empty($r->phone) ? $r->phone : null;

        if (\DB::table('user_otps')->when(!is_null($email), function ($q) use ($email) {
            return $q->whereEmail($email);
        })->when(!is_null($phone), function ($q) use ($phone) {
            return $q->wherePhoneNumber($phone);
        })->whereOtp($otp)->exists()) {
            \DB::table('users')->when(!is_null($email), function ($q) use ($email) {
                return $q->whereEmail($email);
            })->when(!is_null($phone), function ($q) use ($phone) {
                return $q->wherePhoneNumber($phone);
            })->update(['phone_verified' => 'Yes', 'email_verified' => 'Yes']);
            $user = \App\Models\User::when(!is_null($email), function ($q) use ($email) {
                return $q->whereEmail($email);
            })->when(!is_null($phone), function ($q) use ($phone) {
                return $q->wherePhoneNumber($phone);
            })->first();
            $token = Auth::guard('api')->login($user);
            $user->token = $token;
            $user->save();
            Log::info("token  {id}", ['id' =>$token]);
            return response()->json(['message' => 'Otp verified successfully',
                'user' => ['email' => $user->email, 'phone' => $user->phone, 'address' => $user->address, 'name' => $user->name], 'token' => $token], 200);
        } else {
            return response()->json(['message' => 'Otp expired'], 404);
        }

    }
}
